use regex::Regex;
use serde::{Deserialize, Serialize};
use std::{
    fs,
    io::{BufRead, BufReader},
    path::{Path, PathBuf},
    process::{Command, Stdio},
    sync::{
        Arc, Mutex,
        atomic::{AtomicBool, Ordering}
    },
    time::{SystemTime, UNIX_EPOCH},
};
use tauri::{AppHandle, Emitter, Manager, State};

#[cfg(target_os = "windows")]
use std::os::windows::process::CommandExt;

#[cfg(target_os = "windows")]
const CREATE_NO_WINDOW: u32 = 0x08000000;

#[derive(Clone)]
struct AppState {
    download_pid: Arc<Mutex<Option<u32>>>,
    dub_running: Arc<AtomicBool>,
    dub_cancel: Arc<AtomicBool>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
struct Settings {
    media_root: String,
    source_feed_url: String,
    #[serde(default)]
    update_manifest_url: String,
}

#[derive(Debug, Serialize)]
struct ToolStatus {
    ytdlp: bool,
    ffmpeg: bool,
    ffprobe: bool,
    ytdlp_path: Option<String>,
    ffmpeg_path: Option<String>,
}

#[derive(Debug, Serialize)]
struct ElevenStatus {
    ok: bool,
    model: String,
    voice_id_masked: String,
    message: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct SourceItem {
    name: String,
    #[serde(default)]
    name_vi: String,
    #[serde(default)]
    content_type: String,
    #[serde(default)]
    genre: String,
    #[serde(default)]
    platform: String,
    #[serde(default)]
    source_type: String,
    #[serde(default)]
    watermark: String,
    #[serde(default)]
    rank: String,
    #[serde(default)]
    updated: String,
    url: String,
    #[serde(default)]
    backup_url: String,
    #[serde(default)]
    note: String,
}

#[derive(Debug, Serialize, Deserialize)]
struct SourceFeed {
    #[serde(default)]
    updated_at: String,
    #[serde(default)]
    sources: Vec<SourceItem>,
}

#[derive(Debug, Serialize)]
struct ProbeResult {
    title: String,
    duration: Option<f64>,
    playlist_count: Option<u64>,
    webpage_url: Option<String>,
}

#[derive(Debug, Serialize)]
struct SourceStats {
    url: String,
    title: Option<String>,
    view_count: Option<u64>,
    like_count: Option<u64>,
    duration: Option<f64>,
    upload_date: Option<String>,
    checked_at: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct UpdateManifest {
    version: String,
    #[serde(default)]
    zip_url: String,
    #[serde(default)]
    sha256: String,
    #[serde(default)]
    notes: String,
}

#[derive(Debug, Serialize)]
struct DubProjectInfo {
    project_path: String,
    project_name: String,
    source_video: Option<String>,
    srt_zh: Option<String>,
    srt_vi: Option<String>,
    source_width: Option<u32>,
    source_height: Option<u32>,
    source_audio_channels: Option<u32>,
    source_quality: Option<String>,
}

#[derive(Debug, Serialize)]
struct SrtAnalysis {
    count: usize,
    duration_ms: u64,
    warnings: Vec<String>,
}

#[derive(Debug, Deserialize, Clone)]
struct DubRequest {
    project_path: String,
    source_video: String,
    srt_vi: String,
    #[serde(default)]
    srt_zh: String,
    #[serde(default = "default_audio_mode")]
    audio_mode: String,
    #[serde(default)]
    max_captions: usize,
}

fn default_audio_mode() -> String {
    "AUTO_MUTE".into()
}

#[derive(Debug, Serialize, Clone)]
struct DubProgress {
    stage: String,
    current: usize,
    total: usize,
    message: String,
    percent: f64,
}

#[derive(Debug, Serialize, Clone)]
struct DubComplete {
    ok: bool,
    message: String,
    voice_path: Option<String>,
    draft_path: Option<String>,
    warning_count: Option<usize>,
}

#[derive(Debug, Serialize, Clone)]
struct CinematicEngineStatus {
    installed: bool,
    path: Option<String>,
    source: Option<String>,
    message: String,
}

#[derive(Debug, Clone)]
struct SrtEntry {
    start_ms: u64,
    end_ms: u64,
    text: String,
}

#[derive(Debug, Deserialize)]
struct DownloadRequest {
    url: String,
    content_type: String,
    project_name: String,
    quality: String,
    playlist_mode: String,
}

#[derive(Debug, Serialize, Clone)]
struct DownloadProgress {
    line: String,
    percent: Option<f64>,
    speed: Option<String>,
    eta: Option<String>,
    item: Option<String>,
}

#[derive(Debug, Serialize)]
struct ProjectItem {
    content_type: String,
    name: String,
    path: String,
}

fn app_data_dir(app: &AppHandle) -> Result<PathBuf, String> {
    let p = app.path().app_data_dir().map_err(|e| e.to_string())?;
    fs::create_dir_all(&p).map_err(|e| e.to_string())?;
    Ok(p)
}

fn settings_path(app: &AppHandle) -> Result<PathBuf, String> {
    Ok(app_data_dir(app)?.join("settings.json"))
}

fn find_in_path(exe: &str) -> Option<PathBuf> {
    if exe.contains('\\') || exe.contains('/') {
        let p = PathBuf::from(exe);
        return p.exists().then_some(p);
    }
    let path = std::env::var_os("PATH")?;
    for dir in std::env::split_paths(&path) {
        let p = dir.join(exe);
        if p.exists() { return Some(p); }
    }
    None
}

fn find_tool(app: &AppHandle, names: &[&str]) -> Option<PathBuf> {
    if let Ok(resource) = app.path().resource_dir() {
        for name in names {
            let p = resource.join("tools").join(name);
            if p.exists() { return Some(p); }
        }
    }
    for name in names {
        if let Some(p) = find_in_path(name) { return Some(p); }
    }
    None
}


fn managed_cinematic_root(app: &AppHandle) -> Result<PathBuf, String> {
    Ok(app_data_dir(app)?.join("cinematic_engine"))
}

fn managed_demucs_path(app: &AppHandle) -> Result<PathBuf, String> {
    Ok(managed_cinematic_root(app)?
        .join(".venv")
        .join("Scripts")
        .join("demucs-infer.exe"))
}

fn find_cinematic_engine(app: &AppHandle) -> Option<(PathBuf, String)> {
    // Reuse the POC environment if the user already tested CDX23.
    let poc = PathBuf::from(
        r"C:\DEV\TAI_VIDEO_AUDIO_POC\.venv\Scripts\demucs-infer.exe"
    );
    if poc.exists() {
        return Some((poc, "POC environment".into()));
    }

    if let Ok(managed) = managed_demucs_path(app) {
        if managed.exists() {
            return Some((managed, "Managed app environment".into()));
        }
    }

    find_in_path("demucs-infer.exe")
        .map(|p| (p, "Windows PATH".into()))
}

#[tauri::command]
fn check_cinematic_engine(app: AppHandle) -> CinematicEngineStatus {
    if let Some((path, source)) = find_cinematic_engine(&app) {
        CinematicEngineStatus {
            installed: true,
            path: Some(path.to_string_lossy().to_string()),
            source: Some(source),
            message: "CDX23 cinematic separation sẵn sàng.".into(),
        }
    } else {
        CinematicEngineStatus {
            installed: false,
            path: None,
            source: None,
            message: "Chưa có demucs-infer. Bấm Cài/kiểm tra Cinematic Engine.".into(),
        }
    }
}

async fn run_checked(mut cmd: tokio::process::Command, label: &str) -> Result<(), String> {
    let out = cmd.output().await.map_err(|e| format!("{}: {}", label, e))?;
    if out.status.success() {
        Ok(())
    } else {
        let err = String::from_utf8_lossy(&out.stderr);
        let stdout = String::from_utf8_lossy(&out.stdout);
        Err(format!(
            "{} lỗi.\nSTDOUT:\n{}\nSTDERR:\n{}",
            label, stdout, err
        ))
    }
}

#[tauri::command]
async fn install_cinematic_engine(app: AppHandle) -> Result<CinematicEngineStatus, String> {
    if let Some((path, source)) = find_cinematic_engine(&app) {
        return Ok(CinematicEngineStatus {
            installed: true,
            path: Some(path.to_string_lossy().to_string()),
            source: Some(source),
            message: "Engine đã có sẵn.".into(),
        });
    }

    let python = find_in_path("python.exe")
        .or_else(|| find_in_path("python"))
        .ok_or("Không tìm thấy Python trong PATH")?;

    let root = managed_cinematic_root(&app)?;
    fs::create_dir_all(&root).map_err(|e| e.to_string())?;
    let venv = root.join(".venv");
    let venv_python = venv.join("Scripts").join("python.exe");

    if !venv_python.exists() {
        let mut cmd = tokio::process::Command::new(&python);
        cmd.args(["-m", "venv", &venv.to_string_lossy()]);
        run_checked(cmd, "Tạo cinematic venv").await?;
    }

    let mut pip = tokio::process::Command::new(&venv_python);
    pip.args(["-m", "pip", "install", "--upgrade", "pip"]);
    run_checked(pip, "Cập nhật pip").await?;

    let mut torch = tokio::process::Command::new(&venv_python);
    torch.args([
        "-m", "pip", "install",
        "--index-url", "https://download.pytorch.org/whl/cpu",
        "torch", "torchaudio"
    ]);
    run_checked(torch, "Cài PyTorch CPU").await?;

    let mut demucs = tokio::process::Command::new(&venv_python);
    demucs.args(["-m", "pip", "install", "--upgrade", "demucs-infer"]);
    run_checked(demucs, "Cài demucs-infer").await?;

    let exe = managed_demucs_path(&app)?;
    if !exe.exists() {
        return Err("Cài xong nhưng không tìm thấy demucs-infer.exe".into());
    }

    Ok(CinematicEngineStatus {
        installed: true,
        path: Some(exe.to_string_lossy().to_string()),
        source: Some("Managed app environment".into()),
        message: "Cinematic Engine đã cài.".into(),
    })
}

#[tauri::command]
fn check_tools(app: AppHandle) -> ToolStatus {
    let y = find_tool(&app, &["yt-dlp.exe", "yt-dlp"]);
    let f = find_tool(&app, &["ffmpeg.exe", "ffmpeg"]);
    let fp = find_tool(&app, &["ffprobe.exe", "ffprobe"]);
    ToolStatus {
        ytdlp: y.is_some(),
        ffmpeg: f.is_some(),
        ffprobe: fp.is_some(),
        ytdlp_path: y.map(|p| p.to_string_lossy().to_string()),
        ffmpeg_path: f.map(|p| p.to_string_lossy().to_string()),
    }
}

#[tauri::command]
fn check_elevenlabs_env() -> ElevenStatus {
    let key = std::env::var("ELEVENLABS_API_KEY").unwrap_or_default();
    let voice = std::env::var("ELEVENLABS_VOICE_ID").unwrap_or_default();
    let model = std::env::var("ELEVENLABS_MODEL_ID").unwrap_or_else(|_| "eleven_v4".into());
    let ok = !key.trim().is_empty() && !voice.trim().is_empty();
    let masked = if voice.len() > 8 {
        format!("{}…{}", &voice[..4], &voice[voice.len()-4..])
    } else { voice.clone() };
    ElevenStatus {
        ok,
        model: model.clone(),
        voice_id_masked: masked,
        message: if ok { format!("ElevenLabs ENV OK • model={}", model) }
                 else { "Thiếu ELEVENLABS_API_KEY hoặc ELEVENLABS_VOICE_ID".into() },
    }
}

#[tauri::command]
fn get_settings(app: AppHandle) -> Result<Settings, String> {
    let p = settings_path(&app)?;
    if !p.exists() { return Ok(Settings::default()); }
    let s = fs::read_to_string(p).map_err(|e| e.to_string())?;
    serde_json::from_str(&s).map_err(|e| e.to_string())
}

#[tauri::command]
fn save_settings(app: AppHandle, settings: Settings) -> Result<(), String> {
    let p = settings_path(&app)?;
    let s = serde_json::to_string_pretty(&settings).map_err(|e| e.to_string())?;
    fs::write(p, s).map_err(|e| e.to_string())
}

#[tauri::command]
async fn fetch_source_feed(url: String) -> Result<SourceFeed, String> {
    let ts = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_millis();

    let sep = if url.contains('?') { "&" } else { "?" };
    let fresh_url = format!("{}{}ts={}", url, sep, ts);

    let feed = reqwest::Client::new()
        .get(fresh_url)
        .header("User-Agent", "TAI-VIDEO-STUDIO/1.3")
        .header("Cache-Control", "no-cache, no-store, max-age=0")
        .header("Pragma", "no-cache")
        .send().await.map_err(|e| e.to_string())?
        .error_for_status().map_err(|e| e.to_string())?
        .json::<SourceFeed>().await.map_err(|e| e.to_string())?;

    Ok(feed)
}

fn sanitize_name(s: &str) -> String {
    let bad = Regex::new(r#"[<>:"/\\|?*\x00-\x1f]+"#).unwrap();
    let mut out = bad.replace_all(s.trim(), "_").to_string();
    while out.ends_with('.') || out.ends_with(' ') { out.pop(); }
    if out.is_empty() { "UNTITLED".into() } else { out.chars().take(100).collect() }
}

fn ensure_project(media_root: &Path, content_type: &str, project_name: &str) -> Result<PathBuf,String> {
    let bucket = if content_type.eq_ignore_ascii_case("AI") { "PHIM_AI" } else { "PHIM_THAT" };
    let root = media_root.join(bucket).join(sanitize_name(project_name));
    for sub in ["01_SOURCE","02_SUBTITLE","03_SCRIPT","04_VOICE","05_DRAFT","06_FINAL"] {
        fs::create_dir_all(root.join(sub)).map_err(|e| e.to_string())?;
    }
    Ok(root)
}

#[tauri::command]
async fn probe_url(app: AppHandle, url: String) -> Result<ProbeResult,String> {
    let y = find_tool(&app,&["yt-dlp.exe","yt-dlp"]).ok_or("Không tìm thấy yt-dlp")?;
    let out = tokio::process::Command::new(y)
        .args(["--dump-single-json","--skip-download","--no-warnings",&url])
        .output().await.map_err(|e| e.to_string())?;
    if !out.status.success() {
        return Err(String::from_utf8_lossy(&out.stderr).to_string());
    }
    let v: serde_json::Value = serde_json::from_slice(&out.stdout).map_err(|e| e.to_string())?;
    Ok(ProbeResult {
        title: v.get("title").and_then(|x|x.as_str()).unwrap_or("Không rõ tên").to_string(),
        duration: v.get("duration").and_then(|x|x.as_f64()),
        playlist_count: v.get("playlist_count").and_then(|x|x.as_u64())
            .or_else(|| v.get("entries").and_then(|x|x.as_array()).map(|x|x.len() as u64)),
        webpage_url: v.get("webpage_url").and_then(|x|x.as_str()).map(str::to_string),
    })
}

#[tauri::command]
async fn probe_source_stats(app: AppHandle, url: String) -> Result<SourceStats, String> {
    let y = find_tool(&app,&["yt-dlp.exe","yt-dlp"]).ok_or("Không tìm thấy yt-dlp")?;
    let out = tokio::process::Command::new(y)
        .args(["--dump-single-json","--skip-download","--no-warnings",&url])
        .output().await.map_err(|e| e.to_string())?;

    if !out.status.success() {
        return Err(String::from_utf8_lossy(&out.stderr).to_string());
    }

    let v: serde_json::Value = serde_json::from_slice(&out.stdout).map_err(|e| e.to_string())?;
    let checked_at = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_secs()
        .to_string();

    let entries = v.get("entries").and_then(|x| x.as_array());

    let duration = v.get("duration").and_then(|x|x.as_f64()).or_else(|| {
        entries.map(|arr| {
            arr.iter()
                .filter_map(|e| e.get("duration").and_then(|x| x.as_f64()))
                .sum::<f64>()
        }).filter(|sum| *sum > 0.0)
    });

    let view_count = v.get("view_count").and_then(|x|x.as_u64()).or_else(|| {
        entries.and_then(|arr| {
            arr.iter()
                .filter_map(|e| e.get("view_count").and_then(|x| x.as_u64()))
                .max()
        })
    });

    let upload_date = v.get("upload_date").and_then(|x|x.as_str()).map(str::to_string).or_else(|| {
        entries.and_then(|arr| {
            arr.iter()
                .filter_map(|e| e.get("upload_date").and_then(|x| x.as_str()))
                .max()
                .map(str::to_string)
        })
    });

    Ok(SourceStats {
        url,
        title: v.get("title").and_then(|x|x.as_str()).map(str::to_string),
        view_count,
        like_count: v.get("like_count").and_then(|x|x.as_u64()),
        duration,
        upload_date,
        checked_at,
    })
}

fn parse_progress(line: &str) -> DownloadProgress {
    let pct_re = Regex::new(r"\[download\]\s+(\d+(?:\.\d+)?)%").unwrap();
    let speed_re = Regex::new(r"\bat\s+(\S+/s)").unwrap();
    let eta_re = Regex::new(r"\bETA\s+(\S+)").unwrap();
    let item_re = Regex::new(r"Downloading\s+(?:item|video)\s+(\d+)\s+of\s+(\d+)").unwrap();
    DownloadProgress {
        line: line.to_string(),
        percent: pct_re.captures(line).and_then(|c|c.get(1)).and_then(|m|m.as_str().parse().ok()),
        speed: speed_re.captures(line).and_then(|c|c.get(1)).map(|m|m.as_str().to_string()),
        eta: eta_re.captures(line).and_then(|c|c.get(1)).map(|m|m.as_str().to_string()),
        item: item_re.captures(line).map(|c|format!("{}/{}", &c[1], &c[2])),
    }
}

#[tauri::command]
fn start_download(app: AppHandle, state: State<AppState>, req: DownloadRequest) -> Result<String,String> {
    if state.download_pid.lock().unwrap().is_some() {
        return Err("Đang có một tác vụ download chạy.".into());
    }
    let settings = get_settings(app.clone())?;
    if settings.media_root.trim().is_empty() { return Err("Chưa cấu hình Media Root.".into()); }
    let media_root = PathBuf::from(settings.media_root);
    let project = ensure_project(&media_root,&req.content_type,&req.project_name)?;
    let source_dir = project.join("01_SOURCE");
    let y = find_tool(&app,&["yt-dlp.exe","yt-dlp"]).ok_or("Không tìm thấy yt-dlp")?;
    let ffmpeg = find_tool(&app,&["ffmpeg.exe","ffmpeg"]);

    let archive = app_data_dir(&app)?.join("downloaded.txt");
    let mut args: Vec<String> = vec![
        "--newline".into(), "--progress".into(), "--no-quiet".into(), "--no-simulate".into(),
        "--continue".into(), "--retries".into(),"10".into(),"--fragment-retries".into(),"10".into(),
        "--concurrent-fragments".into(),"8".into(),"--windows-filenames".into(),
        "--merge-output-format".into(),"mp4".into(),
        "--download-archive".into(), archive.to_string_lossy().to_string(),
    ];
    if let Some(f) = ffmpeg {
        if let Some(parent)=f.parent() {
            args.push("--ffmpeg-location".into()); args.push(parent.to_string_lossy().to_string());
        }
    }
    match req.quality.as_str() {
        "1080" => { args.extend(["-f".into(),"bv[height<=1080]+ba/b[height<=1080]/b".into()]); }
        "best" => { args.extend(["-f".into(),"bv+ba/b".into()]); }
        _ => { args.extend(["-f".into(),"bv[height<=720]+ba/b[height<=720]/b".into()]); }
    }
    match req.playlist_mode.as_str() {
        "single" => args.push("--no-playlist".into()),
        "playlist" => args.push("--yes-playlist".into()),
        _ => {}
    }
    args.push("-o".into());
    args.push(source_dir.join("%(playlist_index)03d - %(title)s [%(id)s].%(ext)s").to_string_lossy().to_string());
    args.push(req.url.clone());

    let mut cmd = Command::new(y);
    cmd.args(args).stdout(Stdio::piped()).stderr(Stdio::piped());
    #[cfg(target_os = "windows")]
    cmd.creation_flags(CREATE_NO_WINDOW);
    let mut child = cmd.spawn().map_err(|e| e.to_string())?;
    let pid = child.id();
    *state.download_pid.lock().unwrap() = Some(pid);

    let stdout = child.stdout.take();
    let stderr = child.stderr.take();
    let pid_store = state.download_pid.clone();
    let app2 = app.clone();

    if let Some(out) = stdout {
        let app3 = app.clone();
        std::thread::spawn(move || {
            for line in BufReader::new(out).lines().flatten() {
                let _ = app3.emit("download-progress", parse_progress(&line));
            }
        });
    }
    if let Some(err) = stderr {
        let app3 = app.clone();
        std::thread::spawn(move || {
            for line in BufReader::new(err).lines().flatten() {
                let _ = app3.emit("download-progress", parse_progress(&line));
            }
        });
    }
    std::thread::spawn(move || {
        let result = child.wait();
        *pid_store.lock().unwrap() = None;
        match result {
            Ok(status) => {
                let ok=status.success();
                let msg=if ok {"Download hoàn tất.".to_string()} else {format!("Download kết thúc với mã {:?}",status.code())};
                let _=app2.emit("download-complete", serde_json::json!({"ok":ok,"message":msg}));
            }
            Err(e) => { let _=app2.emit("download-complete", serde_json::json!({"ok":false,"message":e.to_string()})); }
        }
    });

    Ok(format!("pid:{}",pid))
}

#[tauri::command]
fn stop_download(state: State<AppState>) -> Result<(),String> {
    let pid = *state.download_pid.lock().unwrap();
    let Some(pid)=pid else { return Ok(()); };
    #[cfg(target_os="windows")]
    {
        let mut cmd=Command::new("taskkill");
        cmd.args(["/PID",&pid.to_string(),"/T","/F"]);
        cmd.creation_flags(CREATE_NO_WINDOW);
        let _=cmd.output();
    }
    Ok(())
}

#[tauri::command]
fn list_projects(media_root: String) -> Result<Vec<ProjectItem>,String> {
    let base=PathBuf::from(media_root);
    let mut out=Vec::new();
    for (bucket,kind) in [("PHIM_AI","AI"),("PHIM_THAT","LIVE_ACTION")] {
        let p=base.join(bucket);
        if !p.exists(){continue}
        for entry in fs::read_dir(p).map_err(|e|e.to_string())?.flatten() {
            if entry.file_type().map(|x|x.is_dir()).unwrap_or(false) {
                out.push(ProjectItem {
                    content_type:kind.into(),
                    name:entry.file_name().to_string_lossy().to_string(),
                    path:entry.path().to_string_lossy().to_string()
                });
            }
        }
    }
    out.sort_by(|a,b|a.name.to_lowercase().cmp(&b.name.to_lowercase()));
    Ok(out)
}



fn pick_largest_mp4(dir: &Path) -> Option<PathBuf> {
    let mut files: Vec<(u64, PathBuf)> = fs::read_dir(dir).ok()?
        .flatten()
        .filter_map(|e| {
            let p = e.path();
            let is_mp4 = p.extension()
                .and_then(|x| x.to_str())
                .map(|x| x.eq_ignore_ascii_case("mp4"))
                .unwrap_or(false);
            if !is_mp4 { return None; }

            let name = p.file_name()?.to_string_lossy().to_lowercase();
            if name.ends_with(".part.mp4") || Regex::new(r"\.f\d+\.mp4$").ok()?.is_match(&name) {
                return None;
            }

            let size = e.metadata().ok()?.len();
            Some((size, p))
        })
        .collect();

    files.sort_by(|a,b| b.0.cmp(&a.0));
    files.first().map(|x| x.1.clone())
}

async fn probe_source_media(
    ffprobe: &Path,
    source: &Path
) -> (Option<u32>, Option<u32>, Option<u32>) {
    let out = tokio::process::Command::new(ffprobe)
        .args([
            "-v", "error",
            "-show_entries", "stream=codec_type,width,height,channels",
            "-of", "json",
            &source.to_string_lossy()
        ])
        .output().await.ok();

    let Some(out) = out else {
        return (None, None, None);
    };
    if !out.status.success() {
        return (None, None, None);
    }

    let Ok(v) = serde_json::from_slice::<serde_json::Value>(&out.stdout) else {
        return (None, None, None);
    };

    let streams = v.get("streams").and_then(|x| x.as_array());
    let mut width = None;
    let mut height = None;
    let mut channels = None;

    if let Some(arr) = streams {
        for s in arr {
            match s.get("codec_type").and_then(|x| x.as_str()) {
                Some("video") if width.is_none() => {
                    width = s.get("width").and_then(|x| x.as_u64()).map(|x| x as u32);
                    height = s.get("height").and_then(|x| x.as_u64()).map(|x| x as u32);
                }
                Some("audio") if channels.is_none() => {
                    channels = s.get("channels").and_then(|x| x.as_u64()).map(|x| x as u32);
                }
                _ => {}
            }
        }
    }

    (width, height, channels)
}

fn source_quality_grade(width: Option<u32>, height: Option<u32>) -> Option<String> {
    let (Some(w), Some(h)) = (width, height) else {
        return Some("UNKNOWN".into());
    };

    let min_side = w.min(h);
    let max_side = w.max(h);

    let grade = if min_side >= 720 && max_side >= 1280 {
        "PASS"
    } else if min_side >= 540 && max_side >= 960 {
        "MEDIUM"
    } else {
        "LOW"
    };

    Some(grade.into())
}

#[tauri::command]
async fn inspect_project(app: AppHandle, project_path: String) -> Result<DubProjectInfo, String> {
    let project = PathBuf::from(&project_path);
    if !project.exists() {
        return Err("Project không tồn tại".into());
    }

    let source_dir = project.join("01_SOURCE");
    let srt_dir = project.join("02_SUBTITLE");

    let source_path = pick_largest_mp4(&source_dir);
    let source_video = source_path.as_ref()
        .map(|p| p.to_string_lossy().to_string());

    let zh = srt_dir.join("SOURCE_ZH.srt");
    let vi = srt_dir.join("VI_CLEAN.srt");

    let mut source_width = None;
    let mut source_height = None;
    let mut source_audio_channels = None;

    if let Some(source) = source_path.as_ref() {
        if let Some(ffprobe) = find_tool(&app, &["ffprobe.exe", "ffprobe"]) {
            let (w, h, ch) = probe_source_media(&ffprobe, source).await;
            source_width = w;
            source_height = h;
            source_audio_channels = ch;
        }
    }

    let source_quality = source_quality_grade(source_width, source_height);

    Ok(DubProjectInfo {
        project_name: project.file_name()
            .map(|x| x.to_string_lossy().to_string())
            .unwrap_or_default(),
        project_path,
        source_video,
        srt_zh: zh.exists().then(|| zh.to_string_lossy().to_string()),
        srt_vi: vi.exists().then(|| vi.to_string_lossy().to_string()),
        source_width,
        source_height,
        source_audio_channels,
        source_quality,
    })
}

#[tauri::command]
fn pick_srt_file(project_path: String, kind: String) -> Result<Option<String>, String> {
    let project = PathBuf::from(&project_path);
    if !project.exists() {
        return Err("Project không tồn tại".into());
    }

    let picked = rfd::FileDialog::new()
        .add_filter("SubRip", &["srt"])
        .pick_file();

    let Some(src) = picked else {
        return Ok(None);
    };

    let subtitle_dir = project.join("02_SUBTITLE");
    fs::create_dir_all(&subtitle_dir).map_err(|e| e.to_string())?;

    let filename = if kind.eq_ignore_ascii_case("zh") {
        "SOURCE_ZH.srt"
    } else {
        "VI_CLEAN.srt"
    };

    let dest = subtitle_dir.join(filename);
    fs::copy(&src, &dest).map_err(|e| e.to_string())?;
    Ok(Some(dest.to_string_lossy().to_string()))
}

fn srt_time_to_ms(raw: &str) -> Result<u64, String> {
    let normalized = raw.trim().replace('.', ",");
    let parts: Vec<&str> = normalized.split(':').collect();
    if parts.len() != 3 {
        return Err(format!("Timestamp SRT không hợp lệ: {}", raw));
    }

    let h: u64 = parts[0].parse().map_err(|_| "Sai giờ SRT")?;
    let m: u64 = parts[1].parse().map_err(|_| "Sai phút SRT")?;
    let sec_ms: Vec<&str> = parts[2].split(',').collect();
    if sec_ms.len() != 2 {
        return Err(format!("Timestamp SRT không hợp lệ: {}", raw));
    }

    let s: u64 = sec_ms[0].parse().map_err(|_| "Sai giây SRT")?;
    let ms: u64 = sec_ms[1].parse().map_err(|_| "Sai mili giây SRT")?;
    Ok(((h * 3600 + m * 60 + s) * 1000) + ms)
}

fn parse_srt_file(path: &Path) -> Result<Vec<SrtEntry>, String> {
    let raw = fs::read_to_string(path).map_err(|e| e.to_string())?;
    let block_re = Regex::new(r"\r?\n\s*\r?\n").map_err(|e| e.to_string())?;
    let mut entries = Vec::new();

    for block in block_re.split(raw.trim()) {
        let lines: Vec<&str> = block.lines().collect();
        let time_index = lines.iter().position(|x| x.contains("-->"));
        let Some(ti) = time_index else { continue; };

        let ts: Vec<&str> = lines[ti].split("-->").collect();
        if ts.len() != 2 { continue; }

        let start_ms = srt_time_to_ms(ts[0])?;
        let end_ms = srt_time_to_ms(ts[1])?;
        if end_ms <= start_ms { continue; }

        let text = lines.iter()
            .skip(ti + 1)
            .map(|x| x.trim())
            .filter(|x| !x.is_empty())
            .collect::<Vec<&str>>()
            .join(" ");

        if text.is_empty() { continue; }

        entries.push(SrtEntry { start_ms, end_ms, text });
    }

    entries.sort_by_key(|x| x.start_ms);
    if entries.is_empty() {
        return Err("Không đọc được caption hợp lệ trong SRT".into());
    }
    Ok(entries)
}

fn analyze_entries(entries: &[SrtEntry]) -> SrtAnalysis {
    let mut warnings = Vec::new();

    for (i, e) in entries.iter().enumerate() {
        let dur = (e.end_ms - e.start_ms) as f64 / 1000.0;
        let chars = e.text.chars().filter(|c| !c.is_whitespace()).count() as f64;
        let cps = chars / dur.max(0.1);

        if dur < 0.65 {
            warnings.push(format!("Câu {} chỉ {:.2}s", i + 1, dur));
        }
        if cps > 20.0 {
            warnings.push(format!("Câu {} khá dày: {:.1} ký tự/s", i + 1, cps));
        }
        if i > 0 && e.start_ms < entries[i-1].end_ms {
            warnings.push(format!("Câu {} overlap câu trước", i + 1));
        }
    }

    SrtAnalysis {
        count: entries.len(),
        duration_ms: entries.last().map(|x| x.end_ms).unwrap_or(0),
        warnings,
    }
}

#[tauri::command]
fn analyze_srt(path: String) -> Result<SrtAnalysis, String> {
    let entries = parse_srt_file(Path::new(&path))?;
    Ok(analyze_entries(&entries))
}

fn atempo_chain(mut ratio: f64) -> String {
    if ratio < 0.5 { ratio = 0.5; }
    let mut parts: Vec<String> = Vec::new();

    while ratio > 2.0 {
        parts.push("atempo=2.0".into());
        ratio /= 2.0;
    }
    while ratio < 0.5 {
        parts.push("atempo=0.5".into());
        ratio /= 0.5;
    }

    parts.push(format!("atempo={:.6}", ratio));
    parts.join(",")
}

async fn media_duration_seconds(ffprobe: &Path, file: &Path) -> Result<f64, String> {
    let out = tokio::process::Command::new(ffprobe)
        .args([
            "-v", "error",
            "-show_entries", "format=duration",
            "-of", "default=nw=1:nk=1",
            &file.to_string_lossy()
        ])
        .output().await.map_err(|e| e.to_string())?;

    if !out.status.success() {
        return Err(String::from_utf8_lossy(&out.stderr).to_string());
    }

    String::from_utf8_lossy(&out.stdout)
        .trim()
        .parse::<f64>()
        .map_err(|e| e.to_string())
}

async fn source_has_audio(ffprobe: &Path, file: &Path) -> bool {
    let out = tokio::process::Command::new(ffprobe)
        .args([
            "-v", "error",
            "-select_streams", "a:0",
            "-show_entries", "stream=index",
            "-of", "csv=p=0",
            &file.to_string_lossy()
        ])
        .output().await;

    match out {
        Ok(x) => x.status.success() && !String::from_utf8_lossy(&x.stdout).trim().is_empty(),
        Err(_) => false
    }
}

async fn make_silence(ffmpeg: &Path, seconds: f64, output: &Path) -> Result<(), String> {
    let status = tokio::process::Command::new(ffmpeg)
        .args([
            "-y",
            "-f", "lavfi",
            "-i", "anullsrc=r=48000:cl=stereo",
            "-t", &format!("{:.3}", seconds.max(0.0)),
            "-c:a", "pcm_s16le",
            &output.to_string_lossy()
        ])
        .status().await.map_err(|e| e.to_string())?;

    if !status.success() {
        return Err("FFmpeg không tạo được silence".into());
    }
    Ok(())
}

async fn eleven_tts(
    client: &reqwest::Client,
    key: &str,
    voice_id: &str,
    model_id: &str,
    text: &str
) -> Result<Vec<u8>, String> {
    let url = format!(
        "https://api.elevenlabs.io/v1/text-to-speech/{}?output_format=mp3_44100_128",
        voice_id
    );

    let body = serde_json::json!({
        "text": text,
        "model_id": model_id,
        "language_code": "vi",
        "voice_settings": {
            "stability": 0.50,
            "similarity_boost": 0.82
        }
    });

    let mut last_error = String::new();

    for attempt in 1..=3 {
        let res = client
            .post(&url)
            .header("xi-api-key", key)
            .header("Content-Type", "application/json")
            .header("Accept", "audio/mpeg")
            .json(&body)
            .send().await;

        match res {
            Ok(resp) => {
                let status = resp.status();
                if status.is_success() {
                    let bytes = resp.bytes().await.map_err(|e| e.to_string())?;
                    if !bytes.is_empty() {
                        return Ok(bytes.to_vec());
                    }
                    last_error = "ElevenLabs trả audio rỗng".into();
                } else {
                    let msg = resp.text().await.unwrap_or_default();
                    last_error = format!("ElevenLabs HTTP {}: {}", status, msg);
                }
            }
            Err(e) => last_error = e.to_string()
        }

        tokio::time::sleep(std::time::Duration::from_millis(800 * attempt)).await;
    }

    Err(last_error)
}

fn emit_dub_progress(
    app: &AppHandle,
    stage: &str,
    current: usize,
    total: usize,
    message: String,
    percent: f64
) {
    let _ = app.emit("dub-progress", DubProgress {
        stage: stage.into(),
        current,
        total,
        message,
        percent,
    });
}


fn merged_mute_ranges(entries: &[SrtEntry], pad_seconds: f64) -> Vec<(f64, f64)> {
    let mut ranges: Vec<(f64, f64)> = entries.iter()
        .map(|e| {
            let start = ((e.start_ms as f64 / 1000.0) - pad_seconds).max(0.0);
            let end = (e.end_ms as f64 / 1000.0) + pad_seconds;
            (start, end)
        })
        .collect();

    if ranges.is_empty() {
        return ranges;
    }

    ranges.sort_by(|a,b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));
    let mut merged: Vec<(f64, f64)> = Vec::new();

    for (start, end) in ranges {
        if let Some(last) = merged.last_mut() {
            if start <= last.1 + 0.03 {
                if end > last.1 {
                    last.1 = end;
                }
                continue;
            }
        }
        merged.push((start, end));
    }

    merged
}


fn build_rewrite_rows(
    entries: &[SrtEntry],
    speed_warnings: &[String]
) -> Result<Vec<String>, String> {
    let severe_re = Regex::new(r"^#(\d+): cần ([0-9.]+)x \| (.*)$")
        .map_err(|e| e.to_string())?;

    let mut rows: Vec<String> = vec![
        "caption,speed_ratio,start_ms,end_ms,text".into()
    ];

    for warning in speed_warnings {
        if let Some(c) = severe_re.captures(warning) {
            let number = c.get(1)
                .and_then(|x| x.as_str().parse::<usize>().ok())
                .unwrap_or(0);
            let ratio = c.get(2)
                .and_then(|x| x.as_str().parse::<f64>().ok())
                .unwrap_or(1.0);

            if ratio > 1.25 && number > 0 && number <= entries.len() {
                let entry = &entries[number - 1];
                let safe_text = entry.text.replace('"', "\"\"");
                rows.push(format!(
                    "{},{:.3},{},{},\"{}\"",
                    number, ratio, entry.start_ms, entry.end_ms, safe_text
                ));
            }
        }
    }

    Ok(rows)
}

fn collect_files_recursive(root: &Path, out: &mut Vec<PathBuf>) {
    let Ok(read) = fs::read_dir(root) else { return; };

    for entry in read.flatten() {
        let path = entry.path();
        if path.is_dir() {
            collect_files_recursive(&path, out);
        } else {
            out.push(path);
        }
    }
}

fn find_stem_file(root: &Path, kind: &str) -> Option<PathBuf> {
    let mut files = Vec::new();
    collect_files_recursive(root, &mut files);

    files.into_iter().find(|p| {
        let ext_ok = p.extension()
            .and_then(|x| x.to_str())
            .map(|x| x.eq_ignore_ascii_case("wav"))
            .unwrap_or(false);

        if !ext_ok { return false; }

        let name = p.file_stem()
            .and_then(|x| x.to_str())
            .unwrap_or("")
            .to_lowercase();

        match kind {
            "music" => name == "music" || name.contains("music"),
            "sfx" => name == "sfx" || name.contains("sfx") || name.contains("effect"),
            "speech" => name == "speech" || name.contains("speech") || name.contains("dialog"),
            _ => false
        }
    })
}

async fn make_audio_chunk(
    ffmpeg: &Path,
    source: &Path,
    start_sec: f64,
    duration_sec: f64,
    out_wav: &Path
) -> Result<(), String> {
    let status = tokio::process::Command::new(ffmpeg)
        .args([
            "-y",
            "-ss", &format!("{:.3}", start_sec),
            "-i", &source.to_string_lossy(),
            "-t", &format!("{:.3}", duration_sec),
            "-vn",
            "-ar", "44100",
            "-ac", "2",
            "-c:a", "pcm_s16le",
            &out_wav.to_string_lossy()
        ])
        .status().await.map_err(|e| e.to_string())?;

    if status.success() {
        Ok(())
    } else {
        Err("FFmpeg không extract được cinematic chunk".into())
    }
}

async fn mix_music_sfx_chunk(
    ffmpeg: &Path,
    music: &Path,
    sfx: &Path,
    out_wav: &Path
) -> Result<(), String> {
    let status = tokio::process::Command::new(ffmpeg)
        .args([
            "-y",
            "-i", &music.to_string_lossy(),
            "-i", &sfx.to_string_lossy(),
            "-filter_complex",
            "[0:a][1:a]amix=inputs=2:duration=longest:normalize=0,alimiter=limit=0.891251[a]",
            "-map", "[a]",
            "-ar", "48000",
            "-ac", "2",
            "-c:a", "pcm_s16le",
            &out_wav.to_string_lossy()
        ])
        .status().await.map_err(|e| e.to_string())?;

    if status.success() {
        Ok(())
    } else {
        Err("FFmpeg không mix được music+sfx".into())
    }
}

async fn build_cinematic_background(
    app: &AppHandle,
    ffmpeg: &Path,
    source: &Path,
    duration_sec: f64,
    temp_root: &Path,
    output_wav: &Path,
    cancel: &Arc<AtomicBool>
) -> Result<usize, String> {
    let (demucs, _) = find_cinematic_engine(app)
        .ok_or("Chưa có Cinematic Engine. Bấm Cài/kiểm tra Cinematic Engine.")?;

    let chunk_seconds = 300.0_f64;
    let total_chunks = ((duration_sec / chunk_seconds).ceil() as usize).max(1);
    let chunks_root = temp_root.join("cinematic_chunks");
    fs::create_dir_all(&chunks_root).map_err(|e| e.to_string())?;

    let mut backgrounds: Vec<PathBuf> = Vec::new();

    for idx in 0..total_chunks {
        if cancel.load(Ordering::SeqCst) {
            return Err("Đã dừng theo yêu cầu".into());
        }

        let start = idx as f64 * chunk_seconds;
        let len = (duration_sec - start).min(chunk_seconds).max(0.1);

        emit_dub_progress(
            app,
            "Cinematic AI",
            idx + 1,
            total_chunks,
            format!(
                "CDX23 chunk {}/{} • {:.1}-{:.1}s",
                idx + 1,
                total_chunks,
                start,
                start + len
            ),
            88.0 + ((idx + 1) as f64 / total_chunks as f64) * 6.0
        );

        let chunk_dir = chunks_root.join(format!("chunk_{:04}", idx + 1));
        let stem_dir = chunk_dir.join("stems");
        fs::create_dir_all(&stem_dir).map_err(|e| e.to_string())?;

        let input_wav = chunk_dir.join("input.wav");
        let bg_wav = chunk_dir.join("background.wav");

        make_audio_chunk(ffmpeg, source, start, len, &input_wav).await?;

        let status = tokio::process::Command::new(&demucs)
            .args([
                "-n", "cdx23_dnr",
                "--device", "cpu",
                "-o", &stem_dir.to_string_lossy(),
                &input_wav.to_string_lossy()
            ])
            .status().await.map_err(|e| e.to_string())?;

        if !status.success() {
            return Err(format!("CDX23 lỗi ở chunk {}", idx + 1));
        }

        let music = find_stem_file(&stem_dir, "music")
            .ok_or_else(|| format!("Không tìm thấy music stem ở chunk {}", idx + 1))?;
        let sfx = find_stem_file(&stem_dir, "sfx")
            .ok_or_else(|| format!("Không tìm thấy sfx stem ở chunk {}", idx + 1))?;

        mix_music_sfx_chunk(ffmpeg, &music, &sfx, &bg_wav).await?;
        backgrounds.push(bg_wav);
    }

    let list = temp_root.join("cinematic_concat.txt");
    let list_text = backgrounds.iter()
        .map(|p| {
            let s = p.to_string_lossy().replace('\\', "/").replace('\'', "'\\''");
            format!("file '{}'", s)
        })
        .collect::<Vec<String>>()
        .join("\n");
    fs::write(&list, list_text).map_err(|e| e.to_string())?;

    let status = tokio::process::Command::new(ffmpeg)
        .args([
            "-y",
            "-f", "concat",
            "-safe", "0",
            "-i", &list.to_string_lossy(),
            "-ar", "48000",
            "-ac", "2",
            "-c:a", "pcm_s16le",
            &output_wav.to_string_lossy()
        ])
        .status().await.map_err(|e| e.to_string())?;

    if !status.success() {
        return Err("Không concat được cinematic background".into());
    }

    Ok(total_chunks)
}

fn speech_mask_expression(entries: &[SrtEntry]) -> String {
    let ranges = merged_mute_ranges(entries, 0.12);
    if ranges.is_empty() {
        return "0".into();
    }

    ranges.iter()
        .map(|(start,end)| format!("between(t,{:.3},{:.3})", start, end))
        .collect::<Vec<String>>()
        .join("+")
}

fn original_audio_filter(
    audio_mode: &str,
    entries: &[SrtEntry],
    channels: Option<u32>
) -> (String, Option<String>) {
    let mask = speech_mask_expression(entries);

    match audio_mode {
        "MUTE_ALL" => (
            "[0:a]volume=0[base]".into(),
            None
        ),
        "KEEP_10" => (
            "[0:a]volume=0.10[base]".into(),
            None
        ),
        "PRESERVE_LITE" => {
            if channels == Some(2) {
                let filter = format!(
                    "[0:a]asplit=2[aorig][aside];\
                     [aorig]volume='if(gt({},0),0,1)':eval=frame[orig];\
                     [aside]pan=stereo|c0=0.5*c0-0.5*c1|c1=0.5*c1-0.5*c0,\
                     volume='if(gt({},0),1,0)':eval=frame,volume=1.25[side];\
                     [orig][side]amix=inputs=2:duration=first:normalize=0[base]",
                    mask, mask
                );
                (filter, None)
            } else {
                let filter = format!(
                    "[0:a]volume='if(gt({},0),0,1)':eval=frame[base]",
                    mask
                );
                (
                    filter,
                    Some("PRESERVE_LITE cần stereo 2 kênh; đã fallback sang AUTO_MUTE.".into())
                )
            }
        },
        _ => {
            let filter = format!(
                "[0:a]volume='if(gt({},0),0,1)':eval=frame[base]",
                mask
            );
            (filter, None)
        }
    }
}


#[tauri::command]
fn start_dub_sync(
    app: AppHandle,
    state: State<AppState>,
    req: DubRequest
) -> Result<(), String> {
    if state.dub_running.swap(true, Ordering::SeqCst) {
        return Err("Đang có tác vụ Dub Sync chạy.".into());
    }

    state.dub_cancel.store(false, Ordering::SeqCst);

    let running = state.dub_running.clone();
    let cancel = state.dub_cancel.clone();

    tauri::async_runtime::spawn(async move {
        let result: Result<DubComplete, String> = async {
            let project = PathBuf::from(&req.project_path);
            let source = PathBuf::from(&req.source_video);
            let srt_vi = PathBuf::from(&req.srt_vi);

            if !source.exists() { return Err("Không tìm thấy video nguồn".into()); }
            if !srt_vi.exists() { return Err("Không tìm thấy SRT Việt".into()); }

            let ffmpeg = find_tool(&app, &["ffmpeg.exe","ffmpeg"])
                .ok_or("Không tìm thấy FFmpeg")?;
            let ffprobe = find_tool(&app, &["ffprobe.exe","ffprobe"])
                .ok_or("Không tìm thấy ffprobe")?;

            let key = std::env::var("ELEVENLABS_API_KEY").unwrap_or_default();
            let voice_id = std::env::var("ELEVENLABS_VOICE_ID").unwrap_or_default();
            let model_id = std::env::var("ELEVENLABS_MODEL_ID")
                .unwrap_or_else(|_| "eleven_v4".into());

            if key.trim().is_empty() || voice_id.trim().is_empty() {
                return Err("Thiếu ELEVENLABS_API_KEY / ELEVENLABS_VOICE_ID".into());
            }

            let all_entries = parse_srt_file(&srt_vi)?;
            let entries: Vec<SrtEntry> = if req.max_captions > 0 {
                all_entries.into_iter().take(req.max_captions).collect()
            } else {
                all_entries
            };

            let total = entries.len();
            if total == 0 {
                return Err("Phạm vi test không có caption nào".into());
            }
            let analysis = analyze_entries(&entries);

            let (mask_entries, mask_source): (Vec<SrtEntry>, String) = {
                let zh_path = PathBuf::from(&req.srt_zh);
                if !req.srt_zh.trim().is_empty() && zh_path.exists() {
                    match parse_srt_file(&zh_path) {
                        Ok(zh_all) => {
                            let scoped: Vec<SrtEntry> = if req.max_captions > 0 {
                                zh_all.into_iter().take(total).collect()
                            } else {
                                zh_all
                            };
                            (scoped, "SOURCE_ZH.srt".into())
                        }
                        Err(_) => (entries.clone(), "VI_CLEAN.srt (fallback)".into())
                    }
                } else {
                    (entries.clone(), "VI_CLEAN.srt".into())
                }
            };

            let voice_dir = project.join("04_VOICE");
            let draft_dir = project.join("05_DRAFT");
            let temp_dir = voice_dir.join("_temp_dub");

            fs::create_dir_all(&voice_dir).map_err(|e| e.to_string())?;
            fs::create_dir_all(&draft_dir).map_err(|e| e.to_string())?;
            if temp_dir.exists() {
                let _ = fs::remove_dir_all(&temp_dir);
            }
            fs::create_dir_all(&temp_dir).map_err(|e| e.to_string())?;

            let client = reqwest::Client::new();
            let tts_cache_dir = voice_dir.join("CACHE_TTS");
            fs::create_dir_all(&tts_cache_dir).map_err(|e| e.to_string())?;

            let mut concat_parts: Vec<PathBuf> = Vec::new();
            let mut speed_warnings: Vec<String> = Vec::new();
            let mut cursor_ms: u64 = 0;
            let mut cache_hits: usize = 0;
            let mut tts_generated: usize = 0;

            for (idx, entry) in entries.iter().enumerate() {
                if cancel.load(Ordering::SeqCst) {
                    return Err("Đã dừng theo yêu cầu".into());
                }

                let current = idx + 1;
                let percent = (current as f64 / total as f64) * 82.0;

                emit_dub_progress(
                    &app,
                    "Eleven v4",
                    current,
                    total,
                    format!("TTS {}/{}: {}", current, total, entry.text.chars().take(70).collect::<String>()),
                    percent
                );

                if entry.start_ms > cursor_ms {
                    let gap_sec = (entry.start_ms - cursor_ms) as f64 / 1000.0;
                    let gap = temp_dir.join(format!("gap_{:04}.wav", current));
                    make_silence(&ffmpeg, gap_sec, &gap).await?;
                    concat_parts.push(gap);
                }

                let raw_mp3 = temp_dir.join(format!("tts_{:04}.mp3", current));
                let fit_wav = temp_dir.join(format!("tts_{:04}_fit.wav", current));

                let cache_mp3 = tts_cache_dir.join(format!("caption_{:04}.mp3", current));
                let cache_meta = tts_cache_dir.join(format!("caption_{:04}.txt", current));
                let signature = format!("{}\n{}\n{}", voice_id, model_id, entry.text);

                let cache_valid = cache_mp3.exists()
                    && cache_meta.exists()
                    && fs::read_to_string(&cache_meta).unwrap_or_default() == signature;

                if cache_valid {
                    fs::copy(&cache_mp3, &raw_mp3).map_err(|e| e.to_string())?;
                    cache_hits += 1;
                } else {
                    let audio = eleven_tts(
                        &client, &key, &voice_id, &model_id, &entry.text
                    ).await?;
                    fs::write(&raw_mp3, &audio).map_err(|e| e.to_string())?;
                    fs::write(&cache_mp3, &audio).map_err(|e| e.to_string())?;
                    fs::write(&cache_meta, &signature).map_err(|e| e.to_string())?;
                    tts_generated += 1;
                }

                let src_dur = media_duration_seconds(&ffprobe, &raw_mp3).await?.max(0.01);
                let target = ((entry.end_ms - entry.start_ms) as f64 / 1000.0).max(0.08);
                let ratio = (src_dur / target).max(1.0);

                if ratio > 1.15 {
                    speed_warnings.push(format!(
                        "#{:03}: cần {:.2}x | {}",
                        current, ratio, entry.text
                    ));
                }

                let fade_out = (target - 0.015).max(0.0);
                let filter = format!(
                    "{},apad,atrim=0:{:.3},afade=t=in:st=0:d=0.010,afade=t=out:st={:.3}:d=0.012",
                    atempo_chain(ratio),
                    target,
                    fade_out
                );

                let status = tokio::process::Command::new(&ffmpeg)
                    .args([
                        "-y",
                        "-i", &raw_mp3.to_string_lossy(),
                        "-filter:a", &filter,
                        "-ar", "48000",
                        "-ac", "2",
                        "-c:a", "pcm_s16le",
                        &fit_wav.to_string_lossy()
                    ])
                    .status().await.map_err(|e| e.to_string())?;

                if !status.success() {
                    return Err(format!("FFmpeg fit audio lỗi ở câu {}", current));
                }

                concat_parts.push(fit_wav);
                cursor_ms = entry.end_ms;
            }

            emit_dub_progress(
                &app, "Ghép voice", total, total,
                "Đang ghép DUB_VOICE_EXACT.wav...".into(), 87.0
            );

            let concat_file = temp_dir.join("concat.txt");
            let concat_text = concat_parts.iter()
                .map(|p| {
                    let s = p.to_string_lossy().replace('\\', "/").replace('\'', "'\\''");
                    format!("file '{}'", s)
                })
                .collect::<Vec<String>>()
                .join("\n");

            fs::write(&concat_file, concat_text).map_err(|e| e.to_string())?;

            let voice_suffix = if req.max_captions > 0 {
                format!("TEST{}", req.max_captions)
            } else {
                "FULL".into()
            };
            let voice_out = voice_dir.join(format!("DUB_VOICE_EXACT_{}.wav", voice_suffix));
            let status = tokio::process::Command::new(&ffmpeg)
                .args([
                    "-y",
                    "-f", "concat",
                    "-safe", "0",
                    "-i", &concat_file.to_string_lossy(),
                    "-af", "loudnorm=I=-16:LRA=11:TP=-1.0",
                    "-ar", "48000",
                    "-ac", "2",
                    "-c:a", "pcm_s16le",
                    &voice_out.to_string_lossy()
                ])
                .status().await.map_err(|e| e.to_string())?;

            if !status.success() {
                return Err("Không ghép được voice track cuối".into());
            }

            let rewrite_rows = build_rewrite_rows(&entries, &speed_warnings)?;
            let rewrite_path = voice_dir.join(format!("NEEDS_REWRITE_{}.csv", voice_suffix));

            if rewrite_rows.len() > 1 {
                fs::write(&rewrite_path, rewrite_rows.join("\n"))
                    .map_err(|e| e.to_string())?;
            } else if rewrite_path.exists() {
                let _ = fs::remove_file(&rewrite_path);
            }

            // Production FULL is blocked when any caption needs >1.25x.
            // Test scopes still render so the user can hear the problem.
            if req.max_captions == 0 && rewrite_rows.len() > 1 {
                let _ = fs::remove_dir_all(&temp_dir);
                return Ok(DubComplete {
                    ok: false,
                    message: format!(
                        "FULL bị chặn bởi Production QC: {} câu cần rút gọn (>1.25x). Xem {}.",
                        rewrite_rows.len() - 1,
                        rewrite_path.to_string_lossy()
                    ),
                    voice_path: Some(voice_out.to_string_lossy().to_string()),
                    draft_path: None,
                    warning_count: Some(speed_warnings.len()),
                });
            }

            emit_dub_progress(
                &app, "Tạo Draft", total, total,
                "Đang ghép voice Việt với video nguồn...".into(), 88.0
            );

            let suffix = if req.max_captions > 0 {
                format!("TEST{}", req.max_captions)
            } else {
                "FULL".into()
            };

            let draft_out = draft_dir.join(format!("DRAFT_DUB_SYNC_{}.mp4", suffix));
            let has_audio = source_has_audio(&ffprobe, &source).await;

            let source_duration = media_duration_seconds(&ffprobe, &source).await.unwrap_or(
                entries.last().map(|x| x.end_ms as f64 / 1000.0).unwrap_or(0.0)
            );

            let draft_duration = if req.max_captions > 0 {
                let test_end = entries.last()
                    .map(|x| x.end_ms as f64 / 1000.0 + 2.0)
                    .unwrap_or(source_duration);
                test_end.min(source_duration).max(0.5)
            } else {
                source_duration.max(0.5)
            };

            let source_channels = if has_audio {
                let out = tokio::process::Command::new(&ffprobe)
                    .args([
                        "-v", "error",
                        "-select_streams", "a:0",
                        "-show_entries", "stream=channels",
                        "-of", "csv=p=0",
                        &source.to_string_lossy()
                    ])
                    .output().await.ok();

                out.and_then(|x| {
                    if x.status.success() {
                        String::from_utf8_lossy(&x.stdout).trim().parse::<u32>().ok()
                    } else {
                        None
                    }
                })
            } else {
                None
            };

            let mut audio_note = String::new();
            let mut cinematic_chunks: usize = 0;
            let mut cinematic_background: Option<PathBuf> = None;

            let draft_status = if req.audio_mode == "HYBRID_CINEMATIC" && has_audio {
                emit_dub_progress(
                    &app, "Cinematic AI", 0, 0,
                    "Đang tách speech / music / SFX bằng CDX23...".into(), 89.0
                );

                let bg_out = voice_dir.join(format!("BACKGROUND_CINEMATIC_{}.wav", suffix));
                cinematic_chunks = build_cinematic_background(
                    &app,
                    &ffmpeg,
                    &source,
                    draft_duration,
                    &temp_dir,
                    &bg_out,
                    &cancel
                ).await?;

                cinematic_background = Some(bg_out.clone());

                let mask = speech_mask_expression(&mask_entries);
                let filter_complex = format!(
                    "[1:a]volume='if(gt({},0),0.18,1)':eval=frame[bg];\
                     [bg][2:a]amix=inputs=2:duration=first:dropout_transition=0:normalize=0,\
                     alimiter=limit=0.891251[a]",
                    mask
                );

                audio_note = format!(
                    "HYBRID_CINEMATIC • {} chunk • mask={} • background duck=18%",
                    cinematic_chunks, mask_source
                );

                tokio::process::Command::new(&ffmpeg)
                    .args([
                        "-y",
                        "-i", &source.to_string_lossy(),
                        "-i", &bg_out.to_string_lossy(),
                        "-i", &voice_out.to_string_lossy(),
                        "-filter_complex", &filter_complex,
                        "-map", "0:v:0",
                        "-map", "[a]",
                        "-t", &format!("{:.3}", draft_duration),
                        "-c:v", "copy",
                        "-c:a", "aac",
                        "-b:a", "192k",
                        "-movflags", "+faststart",
                        &draft_out.to_string_lossy()
                    ])
                    .status().await.map_err(|e| e.to_string())?
            } else if has_audio {
                let (original_filter, preserve_fallback_note) =
                    original_audio_filter(&req.audio_mode, &entries, source_channels);

                let filter_complex = format!(
                    "{};[base][1:a]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[a]",
                    original_filter
                );

                audio_note = preserve_fallback_note.unwrap_or_else(|| req.audio_mode.clone());

                tokio::process::Command::new(&ffmpeg)
                    .args([
                        "-y",
                        "-i", &source.to_string_lossy(),
                        "-i", &voice_out.to_string_lossy(),
                        "-filter_complex", &filter_complex,
                        "-map", "0:v:0",
                        "-map", "[a]",
                        "-t", &format!("{:.3}", draft_duration),
                        "-c:v", "copy",
                        "-c:a", "aac",
                        "-b:a", "192k",
                        "-movflags", "+faststart",
                        &draft_out.to_string_lossy()
                    ])
                    .status().await.map_err(|e| e.to_string())?
            } else {
                audio_note = "Nguồn không có audio; chỉ dùng Eleven v4.".into();

                tokio::process::Command::new(&ffmpeg)
                    .args([
                        "-y",
                        "-i", &source.to_string_lossy(),
                        "-i", &voice_out.to_string_lossy(),
                        "-map", "0:v:0",
                        "-map", "1:a:0",
                        "-t", &format!("{:.3}", draft_duration),
                        "-c:v", "copy",
                        "-c:a", "aac",
                        "-b:a", "192k",
                        "-movflags", "+faststart",
                        &draft_out.to_string_lossy()
                    ])
                    .status().await.map_err(|e| e.to_string())?
            };

            if !draft_status.success() {
                return Err("Không tạo được DRAFT_DUB_SYNC.mp4".into());
            }

            // Keep cinematic background for TEST so the user can audit it.
            // FULL removes it after successful render to save disk.
            if req.max_captions == 0 {
                if let Some(bg) = cinematic_background.as_ref() {
                    let _ = fs::remove_file(bg);
                }
            }

            let report = voice_dir.join(format!("DUB_SYNC_REPORT_{}.txt", voice_suffix));
            let mut report_text = format!(
                "TAI VIDEO STUDIO V1.9.1 - HYBRID CINEMATIC AUDIO\n\
                 Project: {}\n\
                 Source: {}\n\
                 SRT VI: {}\n\
                 Captions processed: {}\n\
                 Timeline ms: {}\n\
                 SRT QC warnings: {}\n\
                 Speed warnings >1.15x: {}\n\
                 Needs rewrite >1.25x: {}\n\
                 Eleven model: {}\n\
                 TTS cache hits: {}\n\
                 TTS generated: {}\n\
                 Audio mode: {}\n\
                 Audio detail: {}\n\
                 Mask source: {}\n\
                 Cinematic chunks: {}\n\
                 Test scope: {}\n\
                 Production QC: {}\n\n\
                 === SPEED WARNINGS ===\n",
                req.project_path,
                req.source_video,
                req.srt_vi,
                total,
                analysis.duration_ms,
                analysis.warnings.len(),
                speed_warnings.len(),
                rewrite_rows.len().saturating_sub(1),
                model_id,
                cache_hits,
                tts_generated,
                req.audio_mode,
                audio_note,
                mask_source,
                cinematic_chunks,
                if req.max_captions > 0 {
                    format!("{} câu đầu", req.max_captions)
                } else {
                    "Toàn bộ SRT".into()
                },
                if rewrite_rows.len() > 1 { "NEEDS_REWRITE" } else { "PASS" }
            );

            report_text.push_str(&speed_warnings.join("\n"));
            report_text.push_str("\n\n=== SRT QC WARNINGS ===\n");
            report_text.push_str(&analysis.warnings.join("\n"));
            fs::write(&report, report_text).map_err(|e| e.to_string())?;

            let _ = fs::remove_dir_all(&temp_dir);

            emit_dub_progress(
                &app, "Hoàn tất", total, total,
                "Dub Sync + Draft hoàn tất.".into(), 100.0
            );

            Ok(DubComplete {
                ok: true,
                message: format!(
                    "Hoàn tất {} câu. Speed warnings >1.15x: {}. Bắt buộc rút gọn >1.25x: {}. TTS cache: {}/{}.",
                    total,
                    speed_warnings.len(),
                    rewrite_rows.len().saturating_sub(1),
                    cache_hits,
                    total
                ),
                voice_path: Some(voice_out.to_string_lossy().to_string()),
                draft_path: Some(draft_out.to_string_lossy().to_string()),
                warning_count: Some(speed_warnings.len()),
            })
        }.await;

        running.store(false, Ordering::SeqCst);

        match result {
            Ok(done) => {
                let _ = app.emit("dub-complete", done);
            }
            Err(e) => {
                let _ = app.emit("dub-complete", DubComplete {
                    ok: false,
                    message: e,
                    voice_path: None,
                    draft_path: None,
                    warning_count: None,
                });
            }
        }
    });

    Ok(())
}

#[tauri::command]
fn stop_dub_sync(state: State<AppState>) -> Result<(), String> {
    state.dub_cancel.store(true, Ordering::SeqCst);
    Ok(())
}

#[tauri::command]
async fn check_update(url: String) -> Result<UpdateManifest, String> {
    let ts = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_millis();
    let sep = if url.contains('?') { "&" } else { "?" };
    let fresh_url = format!("{}{}ts={}", url, sep, ts);

    reqwest::Client::new()
        .get(fresh_url)
        .header("User-Agent", "TAI-VIDEO-STUDIO/1.4")
        .header("Cache-Control", "no-cache, no-store, max-age=0")
        .send().await.map_err(|e| e.to_string())?
        .error_for_status().map_err(|e| e.to_string())?
        .json::<UpdateManifest>().await.map_err(|e| e.to_string())
}

fn ps_quote(s: &str) -> String {
    s.replace('\'', "''")
}

#[tauri::command]
fn apply_update(app: AppHandle, manifest: UpdateManifest) -> Result<(), String> {
    if manifest.zip_url.trim().is_empty() {
        return Err("Manifest chưa có zip_url".into());
    }

    let project_root = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .ok_or("Không xác định được project root")?
        .to_path_buf();

    let temp = std::env::temp_dir().join("TAI_VIDEO_STUDIO_UPDATER");
    fs::create_dir_all(&temp).map_err(|e| e.to_string())?;
    let script = temp.join("apply_update.ps1");

    let ps = format!(r#"
$ErrorActionPreference = "Stop"
$Project = '{project}'
$Zip = Join-Path $env:TEMP 'TAI_VIDEO_STUDIO_UPDATE.zip'
$Stage = Join-Path $env:TEMP 'TAI_VIDEO_STUDIO_UPDATE_STAGE'
$Log = Join-Path $env:TEMP 'TAI_VIDEO_STUDIO_UPDATE.log'

Start-Sleep -Seconds 3
"[$(Get-Date)] START update {version}" | Out-File $Log -Encoding utf8

Invoke-WebRequest -UseBasicParsing -Uri '{zip_url}' -OutFile $Zip

$Expected = '{sha}'
if ($Expected -and $Expected.Trim().Length -gt 0) {{
  $Actual = (Get-FileHash -Algorithm SHA256 $Zip).Hash.ToLower()
  if ($Actual -ne $Expected.ToLower()) {{
    throw "SHA256 mismatch"
  }}
}}

if (Test-Path $Stage) {{ Remove-Item $Stage -Recurse -Force }}
New-Item -ItemType Directory -Force $Stage | Out-Null
Expand-Archive -Path $Zip -DestinationPath $Stage -Force

robocopy $Stage $Project /E /XD node_modules target .git BACKUP_V* /XF *.log | Out-File -Append $Log
$rc = $LASTEXITCODE
if ($rc -ge 8) {{ throw "Robocopy failed: $rc" }}

Remove-Item $Stage -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item $Zip -Force -ErrorAction SilentlyContinue

Set-Location $Project
npm.cmd install | Out-File -Append $Log

Start-Process powershell.exe -ArgumentList '-NoExit','-Command',"Set-Location '$Project'; npm.cmd run tauri dev"
"#,
        project = ps_quote(&project_root.to_string_lossy()),
        version = ps_quote(&manifest.version),
        zip_url = ps_quote(&manifest.zip_url),
        sha = ps_quote(&manifest.sha256),
    );

    fs::write(&script, ps).map_err(|e| e.to_string())?;

    let mut cmd = Command::new("powershell.exe");
    cmd.args([
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File",
        &script.to_string_lossy(),
    ]);
    #[cfg(target_os = "windows")]
    cmd.creation_flags(CREATE_NO_WINDOW);
    cmd.spawn().map_err(|e| e.to_string())?;

    app.exit(0);
    Ok(())
}

#[tauri::command]
fn open_path(path: String) -> Result<(),String> {
    #[cfg(target_os="windows")]
    {
        let mut c=Command::new("explorer.exe"); c.arg(path);
        c.creation_flags(CREATE_NO_WINDOW);
        c.spawn().map_err(|e|e.to_string())?;
    }
    Ok(())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .manage(AppState {
            download_pid: Arc::new(Mutex::new(None)),
            dub_running: Arc::new(AtomicBool::new(false)),
            dub_cancel: Arc::new(AtomicBool::new(false)),
        })
        .invoke_handler(tauri::generate_handler![
            check_tools, check_elevenlabs_env, get_settings, save_settings,
            fetch_source_feed, probe_url, probe_source_stats, start_download, stop_download,
            list_projects, inspect_project, pick_srt_file, analyze_srt, start_dub_sync, stop_dub_sync,
            check_cinematic_engine, install_cinematic_engine,
            check_update, apply_update, open_path
        ])
        .run(tauri::generate_context!())
        .expect("error while running TAI VIDEO STUDIO");
}
