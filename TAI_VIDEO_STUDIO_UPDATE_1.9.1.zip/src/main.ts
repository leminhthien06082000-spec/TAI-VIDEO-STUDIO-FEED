import "./style.css";
import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";

type ToolStatus = {
  ytdlp: boolean;
  ffmpeg: boolean;
  ffprobe: boolean;
  ytdlp_path?: string | null;
  ffmpeg_path?: string | null;
};

type SourceItem = {
  name: string;
  name_vi?: string;
  content_type?: string;
  genre?: string;
  platform?: string;
  source_type?: string;
  watermark?: string;
  rank?: string;
  updated?: string;
  url: string;
  backup_url?: string;
  note?: string;
};

type SourceFeed = { updated_at?: string; sources: SourceItem[] };

type ProjectItem = {
  content_type: string;
  name: string;
  path: string;
};

type DownloadProgress = {
  line: string;
  percent?: number | null;
  speed?: string | null;
  eta?: string | null;
  item?: string | null;
};

type SourceStats = {
  url: string;
  title?: string | null;
  view_count?: number | null;
  like_count?: number | null;
  duration?: number | null;
  upload_date?: string | null;
  checked_at: string;
};

type DubProjectInfo = {
  project_path: string;
  project_name: string;
  source_video?: string | null;
  srt_zh?: string | null;
  srt_vi?: string | null;
  source_width?: number | null;
  source_height?: number | null;
  source_audio_channels?: number | null;
  source_quality?: string | null;
};

type SrtAnalysis = {
  count: number;
  duration_ms: number;
  warnings: string[];
};

type DubProgress = {
  stage: string;
  current: number;
  total: number;
  message: string;
  percent: number;
};

type DubComplete = {
  ok: boolean;
  message: string;
  voice_path?: string | null;
  draft_path?: string | null;
  warning_count?: number | null;
};

type CinematicEngineStatus = {
  installed: boolean;
  path?: string | null;
  source?: string | null;
  message: string;
};

const $ = <T extends HTMLElement>(selector: string) => document.querySelector(selector) as T;

const DEFAULT_UPDATE_MANIFEST = "https://raw.githubusercontent.com/leminhthien06082000-spec/TAI-VIDEO-STUDIO-FEED/main/update_manifest.json";
const APP_VERSION = "1.9.1";

function loadDownloadedUrls(): Set<string> {
  try {
    const raw = localStorage.getItem("taivideo.downloaded.urls");
    const arr = raw ? JSON.parse(raw) : [];
    return new Set(Array.isArray(arr) ? arr : []);
  } catch {
    return new Set();
  }
}

function saveDownloadedUrls(set: Set<string>) {
  localStorage.setItem("taivideo.downloaded.urls", JSON.stringify([...set]));
}

const state = {
  sources: [] as SourceItem[],
  sourceFilter: "ALL",
  tools: null as ToolStatus | null,
  downloadedUrls: loadDownloadedUrls(),
  activeDownloadUrl: "",
  sourceStats: new Map<string, SourceStats>(),
  projects: [] as ProjectItem[],
};

document.querySelector<HTMLDivElement>("#app")!.innerHTML = `
<div class="shell">
  <header class="topbar">
    <div>
      <h1>TAI VIDEO STUDIO</h1>
      <p>V1.9.1 Clean • Tauri + Rust • Local-first</p>
    </div>
    <div class="status-pills">
      <span id="ytdlpPill" class="pill bad">yt-dlp ?</span>
      <span id="ffmpegPill" class="pill bad">FFmpeg ?</span>
      <span id="elevenPill" class="pill neutral">Eleven v4 ?</span>
      <button id="updateAppBtn" class="update-btn">Cập nhật app</button>
    </div>
  </header>

  <nav class="tabs">
    <button class="tab active" data-tab="dashboard">Tổng quan</button>
    <button class="tab" data-tab="sources">Nguồn phim</button>
    <button class="tab" data-tab="download">Tải xuống</button>
    <button class="tab" data-tab="library">Kho phim</button>
    <button class="tab" data-tab="dub">Dub Sync</button>
    <button class="tab" data-tab="settings">Cài đặt</button>
  </nav>

  <main>
    <section id="dashboard" class="panel active">
      <div class="hero card">
        <div>
          <span class="eyebrow">CLEAN REBUILD</span>
          <h2>Một app. Hai kho phim. Không trộn dữ liệu.</h2>
          <p>PHIM AI và PHIM THẬT dùng chung engine, nhưng được lưu thành hai thư mục độc lập.</p>
        </div>
        <div class="hero-actions">
          <button id="goSources" class="primary">Chọn nguồn phim</button>
          <button id="goDownload">Tải video</button>
        </div>
      </div>
      <div class="grid3">
        <div class="card metric"><b>PHIM AI</b><span id="aiCount">0 project</span></div>
        <div class="card metric"><b>PHIM THẬT</b><span id="liveCount">0 project</span></div>
        <div class="card metric"><b>MEDIA ROOT</b><span id="rootSummary">Chưa cấu hình</span></div>
      </div>
      <div class="card">
        <h3>Pipeline đã chốt</h3>
        <div class="flow">
          <span>Nguồn phim</span><i>→</i><span>Download</span><i>→</i><span>SRT</span><i>→</i>
          <span>Eleven v4</span><i>→</i><span>Dub Sync</span><i>→</i><span>Draft</span>
        </div>
      </div>
    </section>

    <section id="sources" class="panel">
      <div class="section-head">
        <div>
          <h2>Nguồn phim</h2>
          <p>Hiển thị Tên Việt + tên gốc. Có STT và trạng thái tải.</p>
        </div>
        <div class="button-row source-actions">
          <button id="refreshSources" class="primary">Cập nhật nguồn</button>
          <button id="refreshStats">Cập nhật thống kê</button>
        </div>
      </div>
      <div class="toolbar">
        <button class="filter active" data-filter="ALL">Tất cả</button>
        <button class="filter" data-filter="AI">Phim AI</button>
        <button class="filter" data-filter="LIVE_ACTION">Phim thật</button>
        <input id="sourceSearch" placeholder="Tìm tên Việt / tên Trung / thể loại..." />
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>STT</th><th>Tên phim</th><th>Loại</th><th>Thể loại</th>
              <th>Nền tảng</th><th>Nguồn</th><th>Watermark</th><th>Rank</th>
              <th>Lượt xem</th><th>Ngày đăng</th><th>Thời lượng</th><th>Trạng thái</th><th></th>
            </tr>
          </thead>
          <tbody id="sourceRows"></tbody>
        </table>
      </div>
    </section>

    <section id="download" class="panel">
      <div class="section-head"><div><h2>Downloader</h2><p>yt-dlp + FFmpeg, tải local vào đúng project.</p></div></div>
      <div class="card form-card">
        <label>URL video / series<input id="downloadUrl" placeholder="https://..." /></label>
        <div class="form-grid">
          <label>Loại phim
            <select id="contentType"><option value="LIVE_ACTION">PHIM THẬT</option><option value="AI">PHIM AI</option></select>
          </label>
          <label>Tên project<input id="projectName" placeholder="VD: XUYEN_KHONG_1960" /></label>
          <label>Chất lượng
            <select id="quality"><option value="720">720p FAST</option><option value="1080">1080p</option><option value="best">BEST</option></select>
          </label>
          <label>Chế độ
            <select id="playlistMode"><option value="auto">Auto</option><option value="single">1 video</option><option value="playlist">Series / playlist</option></select>
          </label>
        </div>
        <div class="button-row">
          <button id="probeBtn">Phân tích link</button>
          <button id="downloadBtn" class="primary">Bắt đầu tải</button>
          <button id="stopBtn" class="danger">Dừng</button>
        </div>
      </div>

      <div class="card">
        <div class="progress-head"><b id="downloadStatus">Sẵn sàng</b><span id="downloadStats">-</span></div>
        <div class="progress"><div id="progressBar"></div></div>
        <pre id="downloadLog" class="log"></pre>
      </div>
    </section>

    <section id="library" class="panel">
      <div class="section-head">
        <div><h2>Kho phim</h2><p>Mỗi project có 6 thư mục chuẩn.</p></div>
        <button id="refreshLibrary">Làm mới</button>
      </div>
      <div class="library-cols">
        <div class="card"><h3>PHIM AI</h3><div id="aiProjects" class="project-list"></div></div>
        <div class="card"><h3>PHIM THẬT</h3><div id="liveProjects" class="project-list"></div></div>
      </div>
    </section>

    <section id="dub" class="panel">
      <div class="section-head">
        <div>
          <h2>Dub Sync – One Voice</h2>
          <p>Một voice Eleven v4 cho tất cả nhân vật, bám từng timestamp SRT.</p>
        </div>
        <button id="refreshDubProjects">Làm mới project</button>
      </div>

      <div class="card form-card">
        <div class="dub-grid">
          <label>Project
            <select id="dubProject">
              <option value="">-- Chọn project đã tải --</option>
            </select>
          </label>
          <label>Chế độ
            <input value="Exact Sync • One Voice" readonly />
          </label>
          <label>Xử lý tiếng gốc
            <select id="dubAudioMode">
              <option value="HYBRID_CINEMATIC" selected>Hybrid Cinematic (khuyên dùng)</option>
              <option value="PRESERVE_LITE">Giữ nhạc/SFX Lite</option>
              <option value="AUTO_MUTE">Auto Mute thoại gốc</option>
              <option value="MUTE_ALL">Tắt tiếng gốc toàn bộ</option>
              <option value="KEEP_10">Giữ 10% tiếng gốc toàn bộ</option>
            </select>
          </label>
        </div>

        <div class="dub-grid dub-grid-range">
          <label>Phạm vi
            <select id="dubRange">
              <option value="10" selected>Test 10 câu đầu</option>
              <option value="30">Test 30 câu đầu</option>
              <option value="0">Toàn bộ SRT</option>
            </select>
          </label>
          <div class="info-box dub-inline-note">
            HYBRID CINEMATIC: AI tách speech / music / SFX; bỏ speech Trung, giữ music+SFX và duck nền còn 18% khi Eleven v4 đang nói. Full dài được chia chunk 5 phút để giảm RAM.
          </div>
        </div>

        <label>Video nguồn
          <input id="dubSourceVideo" readonly placeholder="Tự nhận từ 01_SOURCE" />
        </label>
        <div id="dubSourceQc" class="info-box">Chưa kiểm tra chất lượng nguồn.</div>

        <div class="dub-file-row">
          <label>SRT Trung gốc (tùy chọn)
            <input id="dubSrtZh" readonly placeholder="SOURCE_ZH.srt" />
          </label>
          <button id="pickSrtZh">Chọn SRT Trung</button>
        </div>

        <div class="dub-file-row">
          <label>SRT Việt sạch (bắt buộc)
            <input id="dubSrtVi" readonly placeholder="VI_CLEAN.srt" />
          </label>
          <button id="pickSrtVi" class="primary">Chọn SRT Việt</button>
        </div>

        <div class="button-row">
          <button id="analyzeDubSrt">Phân tích SRT Việt</button>
          <button id="startDubBtn" class="primary">Tạo Dub Sync + Draft</button>
          <button id="stopDubBtn" class="danger">Dừng</button>
          <button id="openVoiceFolder">Mở 04_VOICE</button>
          <button id="openDraftFolder">Mở 05_DRAFT</button>
        </div>

        <div id="elevenDetails" class="info-box">Đang kiểm tra ElevenLabs ENV...</div>
        <div class="cinematic-engine-row">
          <div id="cinematicEngineDetails" class="info-box">Đang kiểm tra Cinematic Engine...</div>
          <button id="installCinematicEngine">Cài/kiểm tra Cinematic Engine</button>
        </div>
        <div id="dubAnalysis" class="info-box">Chưa phân tích SRT.</div>
      </div>

      <div class="card">
        <div class="progress-head">
          <b id="dubStatus">Sẵn sàng</b>
          <span id="dubStats">-</span>
        </div>
        <div class="progress"><div id="dubProgressBar"></div></div>
        <pre id="dubLog" class="log dub-log"></pre>
      </div>
    </section>

    <section id="settings" class="panel">
      <div class="card form-card">
        <h2>Cài đặt</h2>
        <label>Media Root
          <input id="mediaRoot" placeholder="VD: C:\\DEV\\TAI_VIDEO_MEDIA" />
        </label>
        <label>Source Feed URL
          <input id="feedUrl" placeholder="https://raw.githubusercontent.com/.../sources.json" />
        </label>
        <label>Update Manifest URL
          <input id="updateManifestUrl" placeholder="https://raw.githubusercontent.com/.../update_manifest.json" />
        </label>
        <div class="button-row">
          <button id="saveSettings" class="primary">Lưu cài đặt</button>
          <button id="openMediaRoot">Mở kho phim</button>
          <button id="settingsCheckUpdate">Kiểm tra cập nhật</button>
        </div>
        <div class="info-box">
          Secrets không lưu trong app. ElevenLabs đọc từ Windows Environment Variables:
          <code>ELEVENLABS_API_KEY</code>, <code>ELEVENLABS_VOICE_ID</code>, model mặc định <code>eleven_v4</code>.
        </div>
      </div>
    </section>
  </main>
</div>
`;

function switchTab(id: string) {
  document.querySelectorAll(".panel").forEach(x => x.classList.remove("active"));
  document.querySelectorAll(".tab").forEach(x => x.classList.toggle("active", (x as HTMLElement).dataset.tab === id));
  document.getElementById(id)?.classList.add("active");
}
document.querySelectorAll<HTMLButtonElement>(".tab").forEach(b => b.onclick = () => switchTab(b.dataset.tab!));
$("#goSources").onclick = () => switchTab("sources");
$("#goDownload").onclick = () => switchTab("download");

function setPill(el: HTMLElement, ok: boolean, text: string) {
  el.textContent = text;
  el.className = "pill " + (ok ? "good" : "bad");
}

async function loadToolStatus() {
  try {
    const s = await invoke<ToolStatus>("check_tools");
    state.tools = s;
    setPill($("#ytdlpPill"), s.ytdlp, s.ytdlp ? "yt-dlp OK" : "thiếu yt-dlp");
    setPill($("#ffmpegPill"), s.ffmpeg && s.ffprobe, (s.ffmpeg && s.ffprobe) ? "FFmpeg OK" : "thiếu FFmpeg");
  } catch (e) { console.error(e); }
}

async function loadEleven() {
  try {
    const x = await invoke<{ok:boolean; model:string; voice_id_masked:string; message:string}>("check_elevenlabs_env");
    setPill($("#elevenPill"), x.ok, x.ok ? `Eleven ${x.model.replace("eleven_","")} OK` : "Eleven chưa cấu hình");
    $("#elevenDetails").textContent = x.message + (x.voice_id_masked ? ` • Voice: ${x.voice_id_masked}` : "");
  } catch (e) { $("#elevenDetails").textContent = String(e); }
}

async function loadSettings() {
  const s = await invoke<{media_root:string; source_feed_url:string; update_manifest_url?:string}>("get_settings");
  ($("#mediaRoot") as HTMLInputElement).value = s.media_root || "";
  ($("#feedUrl") as HTMLInputElement).value = s.source_feed_url || "";
  ($("#updateManifestUrl") as HTMLInputElement).value = s.update_manifest_url || DEFAULT_UPDATE_MANIFEST;
  $("#rootSummary").textContent = s.media_root || "Chưa cấu hình";
}

$("#saveSettings").onclick = async () => {
  const media_root = ($("#mediaRoot") as HTMLInputElement).value.trim();
  const source_feed_url = ($("#feedUrl") as HTMLInputElement).value.trim();
  const update_manifest_url = ($("#updateManifestUrl") as HTMLInputElement).value.trim() || DEFAULT_UPDATE_MANIFEST;
  await invoke("save_settings", { settings: { media_root, source_feed_url, update_manifest_url } });
  $("#rootSummary").textContent = media_root || "Chưa cấu hình";
  alert("Đã lưu.");
};

$("#openMediaRoot").onclick = async () => {
  const p = ($("#mediaRoot") as HTMLInputElement).value.trim();
  if (p) await invoke("open_path", { path: p });
};

function normalizedType(s: SourceItem) {
  const t = (s.content_type || "").toUpperCase().trim();
  return t === "AI" ? "AI" : "LIVE_ACTION";
}

function sourceDisplayName(s: SourceItem) {
  return (s.name_vi || "").trim() || s.name;
}

function formatViews(v?: number | null) {
  if (v === null || v === undefined) return "-";
  const trim = (n:number) => n.toFixed(1).replace(/\.0$/, "");
  if (v >= 1_000_000_000) return `${trim(v / 1_000_000_000)}B`;
  if (v >= 1_000_000) return `${trim(v / 1_000_000)}M`;
  if (v >= 1_000) return `${trim(v / 1_000)}K`;
  return new Intl.NumberFormat("vi-VN").format(v);
}

function formatUploadDate(raw?: string | null) {
  if (!raw) return "-";
  if (/^\d{8}$/.test(raw)) return `${raw.slice(6,8)}/${raw.slice(4,6)}/${raw.slice(0,4)}`;
  return raw;
}

function formatDuration(seconds?: number | null) {
  if (seconds === null || seconds === undefined || !Number.isFinite(seconds) || seconds <= 0) return "-";
  const totalMinutes = Math.round(seconds / 60);
  if (totalMinutes < 60) return `${totalMinutes} phút`;
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  return m ? `${h}h ${m}p` : `${h}h`;
}

function renderSources() {
  const q = ($("#sourceSearch") as HTMLInputElement).value.toLowerCase().trim();
  const rows = state.sources.filter(s => {
    const type = normalizedType(s);
    const typeOk = state.sourceFilter === "ALL" || type === state.sourceFilter;
    const hay = `${s.name_vi||""} ${s.name} ${s.genre||""} ${s.platform||""}`.toLowerCase();
    return typeOk && (!q || hay.includes(q));
  });

  $("#sourceRows").innerHTML = rows.map((s,i) => {
    const downloaded = state.downloadedUrls.has(s.url);
    const type = normalizedType(s);
    const vi = sourceDisplayName(s);
    const originalIsDifferent = vi !== s.name;
    return `
    <tr>
      <td><b>${i+1}</b></td>
      <td>
        <b>${escapeHtml(vi)}</b>
        ${originalIsDifferent ? `<small>中文: ${escapeHtml(s.name)}</small>` : ""}
        <small>${escapeHtml(s.note||"")}</small>
      </td>
      <td><span class="badge ${type === "AI" ? "ai" : "live"}">${type === "AI" ? "PHIM AI" : "PHIM THẬT"}</span></td>
      <td>${escapeHtml(s.genre||"-")}</td>
      <td>${escapeHtml(s.platform||"-")}</td>
      <td>${escapeHtml(s.source_type||"-")}</td>
      <td>${escapeHtml(s.watermark||"-")}</td>
      <td>${escapeHtml(s.rank||"-")}</td>
      <td><b>${formatViews(state.sourceStats.get(s.url)?.view_count)}</b></td>
      <td>${formatUploadDate(state.sourceStats.get(s.url)?.upload_date)}</td>
      <td><b>${formatDuration(state.sourceStats.get(s.url)?.duration)}</b></td>
      <td>${downloaded ? `<span class="pill good">ĐÃ TẢI</span>` : `<span class="pill neutral">CHƯA TẢI</span>`}</td>
      <td><button data-source="${i}" class="use-source">${downloaded ? "Tải lại" : "Tải"}</button></td>
    </tr>`;
  }).join("");

  document.querySelectorAll<HTMLButtonElement>(".use-source").forEach(btn => {
    btn.onclick = () => {
      const s = rows[Number(btn.dataset.source)];
      ($("#downloadUrl") as HTMLInputElement).value = s.url;
      ($("#contentType") as HTMLSelectElement).value = normalizedType(s);
      ($("#projectName") as HTMLInputElement).value = slugName(sourceDisplayName(s));
      switchTab("download");
    };
  });
}

function escapeHtml(x:string){return x.replace(/[&<>"']/g, c=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[c]!));}
function slugName(x:string){return x.normalize("NFD").replace(/[\u0300-\u036f]/g,"").replace(/[^\p{L}\p{N}]+/gu,"_").replace(/^_+|_+$/g,"").slice(0,80).toUpperCase();}

document.querySelectorAll<HTMLButtonElement>(".filter").forEach(b => b.onclick = () => {
  document.querySelectorAll(".filter").forEach(x => x.classList.remove("active"));
  b.classList.add("active"); state.sourceFilter = b.dataset.filter!; renderSources();
});
($("#sourceSearch") as HTMLInputElement).oninput = renderSources;

async function refreshSources() {
  const url = ($("#feedUrl") as HTMLInputElement).value.trim();
  if (!url) { alert("Chưa có Source Feed URL trong Cài đặt."); return; }
  try {
    const feed = await invoke<SourceFeed>("fetch_source_feed", { url });
    state.sources = feed.sources || [];
    renderSources();
  } catch (e) { alert("Lỗi feed: " + e); }
}
$("#refreshSources").onclick = async () => {
  await refreshSources();
  localStorage.setItem("taivideo.feed.lastDaily", new Date().toISOString().slice(0,10));
};

async function refreshSourceStats() {
  if (!state.sources.length) {
    await refreshSources();
  }
  if (!state.sources.length) return;

  const btn = $("#refreshStats") as HTMLButtonElement;
  btn.disabled = true;
  const oldText = btn.textContent || "";
  let done = 0;

  for (const s of state.sources) {
    btn.textContent = `Thống kê ${done}/${state.sources.length}`;
    try {
      const stats = await invoke<SourceStats>("probe_source_stats", { url: s.url });
      state.sourceStats.set(s.url, stats);
      localStorage.setItem(`taivideo.stats.${s.url}`, JSON.stringify(stats));
      renderSources();
    } catch (e) {
      console.warn("Stats unavailable", s.url, e);
    }
    done++;
  }

  btn.disabled = false;
  btn.textContent = oldText || "Cập nhật thống kê";
  localStorage.setItem("taivideo.stats.lastDaily", new Date().toISOString().slice(0,10));
}

$("#refreshStats").onclick = refreshSourceStats;

function restoreStatsCache() {
  for (const s of state.sources) {
    try {
      const raw = localStorage.getItem(`taivideo.stats.${s.url}`);
      if (raw) state.sourceStats.set(s.url, JSON.parse(raw));
    } catch {}
  }
  renderSources();
}

async function maybeDailyRefresh() {
  const today = new Date().toISOString().slice(0,10);
  const lastFeed = localStorage.getItem("taivideo.feed.lastDaily");
  if (lastFeed !== today) {
    await refreshSources();
    localStorage.setItem("taivideo.feed.lastDaily", today);
  }

  restoreStatsCache();

  const lastStats = localStorage.getItem("taivideo.stats.lastDaily");
  if (lastStats !== today && state.sources.length) {
    // Automatic once-per-day metadata refresh.
    // If a platform does not expose view_count, the cell stays "-".
    await refreshSourceStats();
  }
}

$("#probeBtn").onclick = async () => {
  const url = ($("#downloadUrl") as HTMLInputElement).value.trim();
  if (!url) return;
  $("#downloadStatus").textContent = "Đang phân tích...";
  try {
    const r = await invoke<{title:string; duration?:number; playlist_count?:number; webpage_url?:string}>("probe_url", { url });
    $("#downloadStatus").textContent = r.title;
    $("#downloadStats").textContent = `${r.playlist_count ? r.playlist_count+" phần • " : ""}${r.duration ? Math.round(r.duration/60)+" phút" : ""}`;
    if (!(($("#projectName") as HTMLInputElement).value.trim())) ($("#projectName") as HTMLInputElement).value = slugName(r.title);
  } catch (e) { $("#downloadStatus").textContent = "Lỗi phân tích"; appendLog(String(e)); }
};

function appendLog(s:string) {
  const log = $("#downloadLog");
  log.textContent += s + "\n";
  log.scrollTop = log.scrollHeight;
}

$("#downloadBtn").onclick = async () => {
  const req = {
    url: ($("#downloadUrl") as HTMLInputElement).value.trim(),
    content_type: ($("#contentType") as HTMLSelectElement).value,
    project_name: ($("#projectName") as HTMLInputElement).value.trim(),
    quality: ($("#quality") as HTMLSelectElement).value,
    playlist_mode: ($("#playlistMode") as HTMLSelectElement).value,
  };
  if (!req.url || !req.project_name) { alert("Thiếu URL hoặc tên project."); return; }
  state.activeDownloadUrl = req.url;
  $("#downloadLog").textContent = "";
  $("#downloadStatus").textContent = "Đang khởi động...";
  try { await invoke("start_download", { req }); }
  catch(e){ appendLog(String(e)); $("#downloadStatus").textContent="Không khởi động được"; state.activeDownloadUrl=""; }
};

$("#stopBtn").onclick = async () => { try { await invoke("stop_download"); } catch(e){ appendLog(String(e)); } };

listen<DownloadProgress>("download-progress", e => {
  const p = e.payload;
  appendLog(p.line);
  if (typeof p.percent === "number") ($("#progressBar") as HTMLElement).style.width = `${Math.max(0,Math.min(100,p.percent))}%`;
  $("#downloadStats").textContent = `${p.item||""} ${p.speed||""} ${p.eta ? "ETA "+p.eta : ""}`.trim() || "-";
  $("#downloadStatus").textContent = "Đang tải";
});

listen<{ok:boolean; message:string}>("download-complete", e => {
  $("#downloadStatus").textContent = e.payload.ok ? "Hoàn tất" : "Lỗi";
  appendLog(e.payload.message);
  if (e.payload.ok && state.activeDownloadUrl) {
    state.downloadedUrls.add(state.activeDownloadUrl);
    saveDownloadedUrls(state.downloadedUrls);
    renderSources();
  }
  state.activeDownloadUrl = "";
  loadLibrary();
});

async function loadLibrary() {
  try {
    const media_root = ($("#mediaRoot") as HTMLInputElement).value.trim();
    if (!media_root) return;
    const rows = await invoke<ProjectItem[]>("list_projects", { mediaRoot: media_root });
    state.projects = rows;
    renderDubProjectOptions();
    const ai = rows.filter(x=>x.content_type==="AI");
    const live = rows.filter(x=>x.content_type==="LIVE_ACTION");
    $("#aiCount").textContent = `${ai.length} project`;
    $("#liveCount").textContent = `${live.length} project`;
    const render = (xs:ProjectItem[]) => xs.length ? xs.map(x=>`<button class="project-card" data-path="${escapeHtml(x.path)}"><b>${escapeHtml(x.name)}</b><small>${escapeHtml(x.path)}</small></button>`).join("") : `<p class="muted">Chưa có project.</p>`;
    $("#aiProjects").innerHTML = render(ai);
    $("#liveProjects").innerHTML = render(live);
    document.querySelectorAll<HTMLButtonElement>(".project-card").forEach(b=>b.onclick=()=>invoke("open_path",{path:b.dataset.path}));
  } catch(e){ console.error(e); }
}
$("#refreshLibrary").onclick = loadLibrary;




async function loadCinematicEngine() {
  try {
    const s = await invoke<CinematicEngineStatus>("check_cinematic_engine");
    const el = $("#cinematicEngineDetails");
    el.innerHTML = s.installed
      ? `<b>Cinematic Engine: READY</b> • ${escapeHtml(s.source || "")}<br><small>${escapeHtml(s.path || "")}</small>`
      : `<b>Cinematic Engine: CHƯA CÀI</b><br>${escapeHtml(s.message)}`;
  } catch (e) {
    $("#cinematicEngineDetails").textContent = "Lỗi kiểm tra Cinematic Engine: " + e;
  }
}

$("#installCinematicEngine").onclick = async () => {
  const btn = $("#installCinematicEngine") as HTMLButtonElement;
  const old = btn.textContent || "";
  btn.disabled = true;
  btn.textContent = "Đang cài...";
  $("#cinematicEngineDetails").textContent =
    "Đang cài PyTorch CPU + demucs-infer. Lần đầu có thể tải khá nhiều dữ liệu...";
  try {
    const s = await invoke<CinematicEngineStatus>("install_cinematic_engine");
    $("#cinematicEngineDetails").innerHTML =
      `<b>Cinematic Engine: READY</b> • ${escapeHtml(s.source || "")}<br><small>${escapeHtml(s.path || "")}</small>`;
  } catch (e) {
    alert("Cài Cinematic Engine lỗi: " + e);
    await loadCinematicEngine();
  } finally {
    btn.disabled = false;
    btn.textContent = old || "Cài/kiểm tra Cinematic Engine";
  }
};

function renderDubProjectOptions() {
  const select = $("#dubProject") as HTMLSelectElement;
  if (!select) return;

  const current = select.value;
  select.innerHTML = `<option value="">-- Chọn project đã tải --</option>` +
    state.projects.map(p =>
      `<option value="${escapeHtml(p.path)}">${p.content_type === "AI" ? "[AI]" : "[THẬT]"} ${escapeHtml(p.name)}</option>`
    ).join("");

  if (current && state.projects.some(p => p.path === current)) {
    select.value = current;
  }
}

async function inspectDubProject() {
  const projectPath = ($("#dubProject") as HTMLSelectElement).value;
  if (!projectPath) {
    ($("#dubSourceVideo") as HTMLInputElement).value = "";
    ($("#dubSrtZh") as HTMLInputElement).value = "";
    ($("#dubSrtVi") as HTMLInputElement).value = "";
    return;
  }

  try {
    const info = await invoke<DubProjectInfo>("inspect_project", { projectPath });
    ($("#dubSourceVideo") as HTMLInputElement).value = info.source_video || "";
    ($("#dubSrtZh") as HTMLInputElement).value = info.srt_zh || "";
    ($("#dubSrtVi") as HTMLInputElement).value = info.srt_vi || "";

    const dims = info.source_width && info.source_height
      ? `${info.source_width}×${info.source_height}`
      : "không rõ";
    const channels = info.source_audio_channels
      ? `${info.source_audio_channels} kênh audio`
      : "audio không rõ";
    const grade = info.source_quality || "UNKNOWN";
    $("#dubSourceQc").innerHTML =
      `<b>Source QC: ${escapeHtml(grade)}</b> • ${dims} • ${channels}` +
      (grade === "LOW" ? `<br><span class="qc-warn">Nguồn dưới chuẩn 720p; dùng test được nhưng nên tìm source tốt hơn cho bản final.</span>` : "");

    $("#dubStatus").textContent = info.source_video ? "Project sẵn sàng" : "Chưa có video trong 01_SOURCE";
  } catch (e) {
    $("#dubStatus").textContent = "Lỗi đọc project";
    appendDubLog(String(e));
  }
}

function appendDubLog(line:string) {
  const log = $("#dubLog");
  log.textContent += line + "\n";
  log.scrollTop = log.scrollHeight;
}

($("#dubProject") as HTMLSelectElement).onchange = inspectDubProject;
$("#refreshDubProjects").onclick = async () => {
  await loadLibrary();
  await inspectDubProject();
};

async function pickDubSrt(kind:"zh"|"vi") {
  const projectPath = ($("#dubProject") as HTMLSelectElement).value;
  if (!projectPath) {
    alert("Chọn project trước.");
    return;
  }

  try {
    const path = await invoke<string | null>("pick_srt_file", { projectPath, kind });
    if (!path) return;
    if (kind === "zh") ($("#dubSrtZh") as HTMLInputElement).value = path;
    else ($("#dubSrtVi") as HTMLInputElement).value = path;
  } catch (e) {
    alert("Không nhập được SRT: " + e);
  }
}

$("#pickSrtZh").onclick = () => pickDubSrt("zh");
$("#pickSrtVi").onclick = () => pickDubSrt("vi");

$("#analyzeDubSrt").onclick = async () => {
  const path = ($("#dubSrtVi") as HTMLInputElement).value.trim();
  if (!path) {
    alert("Chọn SRT Việt trước.");
    return;
  }

  try {
    const a = await invoke<SrtAnalysis>("analyze_srt", { path });
    const mins = Math.floor(a.duration_ms / 60000);
    const secs = Math.floor((a.duration_ms % 60000) / 1000);
    const warningText = a.warnings.length
      ? `<br><b>Cảnh báo:</b> ${a.warnings.length}<br>${a.warnings.slice(0,6).map(escapeHtml).join("<br>")}`
      : `<br><b>QC:</b> PASS`;
    $("#dubAnalysis").innerHTML =
      `<b>${a.count} câu</b> • timeline ${mins}:${String(secs).padStart(2,"0")}${warningText}`;
  } catch (e) {
    $("#dubAnalysis").textContent = "Lỗi SRT: " + e;
  }
};

$("#openVoiceFolder").onclick = async () => {
  const p = ($("#dubProject") as HTMLSelectElement).value;
  if (p) await invoke("open_path", { path: `${p}\\04_VOICE` });
};
$("#openDraftFolder").onclick = async () => {
  const p = ($("#dubProject") as HTMLSelectElement).value;
  if (p) await invoke("open_path", { path: `${p}\\05_DRAFT` });
};

$("#startDubBtn").onclick = async () => {
  const project_path = ($("#dubProject") as HTMLSelectElement).value;
  const source_video = ($("#dubSourceVideo") as HTMLInputElement).value.trim();
  const srt_vi = ($("#dubSrtVi") as HTMLInputElement).value.trim();
  const srt_zh = ($("#dubSrtZh") as HTMLInputElement).value.trim();
  const audio_mode = ($("#dubAudioMode") as HTMLSelectElement).value;
  const max_captions = Number(($("#dubRange") as HTMLSelectElement).value);

  if (!project_path || !source_video || !srt_vi) {
    alert("Cần chọn project có video nguồn và SRT Việt sạch.");
    return;
  }

  if (audio_mode === "HYBRID_CINEMATIC" && max_captions === 0) {
    const ok = confirm(
      "Hybrid Cinematic FULL sẽ chạy AI separation bằng CPU theo chunk 5 phút. " +
      "Phim dài có thể mất nhiều thời gian. Tiếp tục?"
    );
    if (!ok) return;
  }

  $("#dubLog").textContent = "";
  $("#dubStatus").textContent = "Đang khởi động Dub Sync...";
  ($("#dubProgressBar") as HTMLElement).style.width = "0%";

  try {
    await invoke("start_dub_sync", {
      req: { project_path, source_video, srt_vi, srt_zh, audio_mode, max_captions }
    });
  } catch (e) {
    $("#dubStatus").textContent = "Không khởi động được";
    appendDubLog(String(e));
  }
};

$("#stopDubBtn").onclick = async () => {
  try {
    await invoke("stop_dub_sync");
  } catch (e) {
    appendDubLog(String(e));
  }
};

listen<DubProgress>("dub-progress", e => {
  const p = e.payload;
  $("#dubStatus").textContent = p.stage;
  $("#dubStats").textContent = p.total ? `${p.current}/${p.total}` : "";
  ($("#dubProgressBar") as HTMLElement).style.width = `${Math.max(0,Math.min(100,p.percent))}%`;
  appendDubLog(p.message);
});

listen<DubComplete>("dub-complete", e => {
  const r = e.payload;
  $("#dubStatus").textContent = r.ok ? "Dub Sync hoàn tất" : "Dub Sync lỗi";
  $("#dubStats").textContent = r.warning_count ? `${r.warning_count} cảnh báo tốc độ` : "";
  appendDubLog(r.message);
  if (r.voice_path) appendDubLog("VOICE: " + r.voice_path);
  if (r.draft_path) appendDubLog("DRAFT: " + r.draft_path);
  if (r.ok) alert("Dub Sync + Draft đã hoàn tất.");
});


type UpdateManifest = {
  version: string;
  zip_url?: string;
  sha256?: string;
  notes?: string;
};

function versionParts(v:string) {
  return v.replace(/^v/i,"").split(".").map(x => parseInt(x,10) || 0);
}
function isNewerVersion(remote:string, current:string) {
  const a=versionParts(remote), b=versionParts(current);
  for (let i=0;i<Math.max(a.length,b.length);i++) {
    const x=a[i]||0, y=b[i]||0;
    if (x!==y) return x>y;
  }
  return false;
}

async function checkAppUpdate() {
  const btn = $("#updateAppBtn") as HTMLButtonElement;
  const old = btn.textContent || "Cập nhật app";
  btn.disabled = true;
  btn.textContent = "Đang kiểm tra...";
  try {
    const url = (($("#updateManifestUrl") as HTMLInputElement)?.value || DEFAULT_UPDATE_MANIFEST).trim() || DEFAULT_UPDATE_MANIFEST;
    const manifest = await invoke<UpdateManifest>("check_update", { url });
    if (!isNewerVersion(manifest.version, APP_VERSION)) {
      alert(`Bạn đang dùng bản mới nhất (${APP_VERSION}).`);
      return;
    }
    if (!manifest.zip_url) {
      alert(`Có bản ${manifest.version} nhưng manifest chưa có zip_url.`);
      return;
    }
    const notes = manifest.notes ? `\\n\\n${manifest.notes}` : "";
    const ok = confirm(`Có bản mới ${manifest.version}.${notes}\\n\\nCập nhật ngay?\\nApp sẽ tự đóng, cập nhật và mở lại.`);
    if (!ok) return;

    btn.textContent = "Đang cập nhật...";
    await invoke("apply_update", { manifest });
  } catch (e) {
    alert("Lỗi cập nhật: " + e);
  } finally {
    btn.disabled = false;
    btn.textContent = old;
  }
}

$("#updateAppBtn").onclick = checkAppUpdate;
$("#settingsCheckUpdate").onclick = checkAppUpdate;

async function startup() {
  await Promise.all([loadToolStatus(), loadEleven(), loadSettings(), loadCinematicEngine()]);
  await loadLibrary();
  await maybeDailyRefresh();
}
startup();
