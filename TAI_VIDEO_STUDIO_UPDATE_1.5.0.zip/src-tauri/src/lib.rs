use regex::Regex;
use serde::{Deserialize, Serialize};
use std::{
    fs,
    io::{BufRead, BufReader},
    path::{Path, PathBuf},
    process::{Command, Stdio},
    sync::{Arc, Mutex},
    time::{SystemTime, UNIX_EPOCH},
};
use tauri::{AppHandle, Emitter, Manager, State};

#[cfg(target_os = "windows")]
use std::os::windows::process::CommandExt;

#[cfg(target_os = "windows")]
const CREATE_NO_WINDOW: u32 = 0x08000000;

#[derive(Clone)]
struct AppState {
    download_pid: Arc<Mutex<Option<u32>>>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
struct Settings {
    media_root: String,
    source_feed_url: String,
    #[serde(default)]
    update_manifest_url: String,
}

#[derive(Debug, Serialize)]
struct ToolStatus {
    ytdlp: bool,
    ffmpeg: bool,
    ffprobe: bool,
    ytdlp_path: Option<String>,
    ffmpeg_path: Option<String>,
}

#[derive(Debug, Serialize)]
struct ElevenStatus {
    ok: bool,
    model: String,
    voice_id_masked: String,
    message: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct SourceItem {
    name: String,
    #[serde(default)]
    name_vi: String,
    #[serde(default)]
    content_type: String,
    #[serde(default)]
    genre: String,
    #[serde(default)]
    platform: String,
    #[serde(default)]
    source_type: String,
    #[serde(default)]
    watermark: String,
    #[serde(default)]
    rank: String,
    #[serde(default)]
    updated: String,
    url: String,
    #[serde(default)]
    backup_url: String,
    #[serde(default)]
    note: String,
}

#[derive(Debug, Serialize, Deserialize)]
struct SourceFeed {
    #[serde(default)]
    updated_at: String,
    #[serde(default)]
    sources: Vec<SourceItem>,
}

#[derive(Debug, Serialize)]
struct ProbeResult {
    title: String,
    duration: Option<f64>,
    playlist_count: Option<u64>,
    webpage_url: Option<String>,
}

#[derive(Debug, Serialize)]
struct SourceStats {
    url: String,
    title: Option<String>,
    view_count: Option<u64>,
    like_count: Option<u64>,
    duration: Option<f64>,
    upload_date: Option<String>,
    checked_at: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
struct UpdateManifest {
    version: String,
    #[serde(default)]
    zip_url: String,
    #[serde(default)]
    sha256: String,
    #[serde(default)]
    notes: String,
}

#[derive(Debug, Deserialize)]
struct DownloadRequest {
    url: String,
    content_type: String,
    project_name: String,
    quality: String,
    playlist_mode: String,
}

#[derive(Debug, Serialize, Clone)]
struct DownloadProgress {
    line: String,
    percent: Option<f64>,
    speed: Option<String>,
    eta: Option<String>,
    item: Option<String>,
}

#[derive(Debug, Serialize)]
struct ProjectItem {
    content_type: String,
    name: String,
    path: String,
}

fn app_data_dir(app: &AppHandle) -> Result<PathBuf, String> {
    let p = app.path().app_data_dir().map_err(|e| e.to_string())?;
    fs::create_dir_all(&p).map_err(|e| e.to_string())?;
    Ok(p)
}

fn settings_path(app: &AppHandle) -> Result<PathBuf, String> {
    Ok(app_data_dir(app)?.join("settings.json"))
}

fn find_in_path(exe: &str) -> Option<PathBuf> {
    if exe.contains('\\') || exe.contains('/') {
        let p = PathBuf::from(exe);
        return p.exists().then_some(p);
    }
    let path = std::env::var_os("PATH")?;
    for dir in std::env::split_paths(&path) {
        let p = dir.join(exe);
        if p.exists() { return Some(p); }
    }
    None
}

fn find_tool(app: &AppHandle, names: &[&str]) -> Option<PathBuf> {
    if let Ok(resource) = app.path().resource_dir() {
        for name in names {
            let p = resource.join("tools").join(name);
            if p.exists() { return Some(p); }
        }
    }
    for name in names {
        if let Some(p) = find_in_path(name) { return Some(p); }
    }
    None
}

#[tauri::command]
fn check_tools(app: AppHandle) -> ToolStatus {
    let y = find_tool(&app, &["yt-dlp.exe", "yt-dlp"]);
    let f = find_tool(&app, &["ffmpeg.exe", "ffmpeg"]);
    let fp = find_tool(&app, &["ffprobe.exe", "ffprobe"]);
    ToolStatus {
        ytdlp: y.is_some(),
        ffmpeg: f.is_some(),
        ffprobe: fp.is_some(),
        ytdlp_path: y.map(|p| p.to_string_lossy().to_string()),
        ffmpeg_path: f.map(|p| p.to_string_lossy().to_string()),
    }
}

#[tauri::command]
fn check_elevenlabs_env() -> ElevenStatus {
    let key = std::env::var("ELEVENLABS_API_KEY").unwrap_or_default();
    let voice = std::env::var("ELEVENLABS_VOICE_ID").unwrap_or_default();
    let model = std::env::var("ELEVENLABS_MODEL_ID").unwrap_or_else(|_| "eleven_v4".into());
    let ok = !key.trim().is_empty() && !voice.trim().is_empty();
    let masked = if voice.len() > 8 {
        format!("{}…{}", &voice[..4], &voice[voice.len()-4..])
    } else { voice.clone() };
    ElevenStatus {
        ok,
        model: model.clone(),
        voice_id_masked: masked,
        message: if ok { format!("ElevenLabs ENV OK • model={}", model) }
                 else { "Thiếu ELEVENLABS_API_KEY hoặc ELEVENLABS_VOICE_ID".into() },
    }
}

#[tauri::command]
fn get_settings(app: AppHandle) -> Result<Settings, String> {
    let p = settings_path(&app)?;
    if !p.exists() { return Ok(Settings::default()); }
    let s = fs::read_to_string(p).map_err(|e| e.to_string())?;
    serde_json::from_str(&s).map_err(|e| e.to_string())
}

#[tauri::command]
fn save_settings(app: AppHandle, settings: Settings) -> Result<(), String> {
    let p = settings_path(&app)?;
    let s = serde_json::to_string_pretty(&settings).map_err(|e| e.to_string())?;
    fs::write(p, s).map_err(|e| e.to_string())
}

#[tauri::command]
async fn fetch_source_feed(url: String) -> Result<SourceFeed, String> {
    let ts = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_millis();

    let sep = if url.contains('?') { "&" } else { "?" };
    let fresh_url = format!("{}{}ts={}", url, sep, ts);

    let feed = reqwest::Client::new()
        .get(fresh_url)
        .header("User-Agent", "TAI-VIDEO-STUDIO/1.3")
        .header("Cache-Control", "no-cache, no-store, max-age=0")
        .header("Pragma", "no-cache")
        .send().await.map_err(|e| e.to_string())?
        .error_for_status().map_err(|e| e.to_string())?
        .json::<SourceFeed>().await.map_err(|e| e.to_string())?;

    Ok(feed)
}

fn sanitize_name(s: &str) -> String {
    let bad = Regex::new(r#"[<>:"/\\|?*\x00-\x1f]+"#).unwrap();
    let mut out = bad.replace_all(s.trim(), "_").to_string();
    while out.ends_with('.') || out.ends_with(' ') { out.pop(); }
    if out.is_empty() { "UNTITLED".into() } else { out.chars().take(100).collect() }
}

fn ensure_project(media_root: &Path, content_type: &str, project_name: &str) -> Result<PathBuf,String> {
    let bucket = if content_type.eq_ignore_ascii_case("AI") { "PHIM_AI" } else { "PHIM_THAT" };
    let root = media_root.join(bucket).join(sanitize_name(project_name));
    for sub in ["01_SOURCE","02_SUBTITLE","03_SCRIPT","04_VOICE","05_DRAFT","06_FINAL"] {
        fs::create_dir_all(root.join(sub)).map_err(|e| e.to_string())?;
    }
    Ok(root)
}

#[tauri::command]
async fn probe_url(app: AppHandle, url: String) -> Result<ProbeResult,String> {
    let y = find_tool(&app,&["yt-dlp.exe","yt-dlp"]).ok_or("Không tìm thấy yt-dlp")?;
    let out = tokio::process::Command::new(y)
        .args(["--dump-single-json","--skip-download","--no-warnings",&url])
        .output().await.map_err(|e| e.to_string())?;
    if !out.status.success() {
        return Err(String::from_utf8_lossy(&out.stderr).to_string());
    }
    let v: serde_json::Value = serde_json::from_slice(&out.stdout).map_err(|e| e.to_string())?;
    Ok(ProbeResult {
        title: v.get("title").and_then(|x|x.as_str()).unwrap_or("Không rõ tên").to_string(),
        duration: v.get("duration").and_then(|x|x.as_f64()),
        playlist_count: v.get("playlist_count").and_then(|x|x.as_u64())
            .or_else(|| v.get("entries").and_then(|x|x.as_array()).map(|x|x.len() as u64)),
        webpage_url: v.get("webpage_url").and_then(|x|x.as_str()).map(str::to_string),
    })
}

#[tauri::command]
async fn probe_source_stats(app: AppHandle, url: String) -> Result<SourceStats, String> {
    let y = find_tool(&app,&["yt-dlp.exe","yt-dlp"]).ok_or("Không tìm thấy yt-dlp")?;
    let out = tokio::process::Command::new(y)
        .args(["--dump-single-json","--skip-download","--no-warnings",&url])
        .output().await.map_err(|e| e.to_string())?;

    if !out.status.success() {
        return Err(String::from_utf8_lossy(&out.stderr).to_string());
    }

    let v: serde_json::Value = serde_json::from_slice(&out.stdout).map_err(|e| e.to_string())?;
    let checked_at = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_secs()
        .to_string();

    let entries = v.get("entries").and_then(|x| x.as_array());

    let duration = v.get("duration").and_then(|x|x.as_f64()).or_else(|| {
        entries.map(|arr| {
            arr.iter()
                .filter_map(|e| e.get("duration").and_then(|x| x.as_f64()))
                .sum::<f64>()
        }).filter(|sum| *sum > 0.0)
    });

    let view_count = v.get("view_count").and_then(|x|x.as_u64()).or_else(|| {
        entries.and_then(|arr| {
            arr.iter()
                .filter_map(|e| e.get("view_count").and_then(|x| x.as_u64()))
                .max()
        })
    });

    let upload_date = v.get("upload_date").and_then(|x|x.as_str()).map(str::to_string).or_else(|| {
        entries.and_then(|arr| {
            arr.iter()
                .filter_map(|e| e.get("upload_date").and_then(|x| x.as_str()))
                .max()
                .map(str::to_string)
        })
    });

    Ok(SourceStats {
        url,
        title: v.get("title").and_then(|x|x.as_str()).map(str::to_string),
        view_count,
        like_count: v.get("like_count").and_then(|x|x.as_u64()),
        duration,
        upload_date,
        checked_at,
    })
}

fn parse_progress(line: &str) -> DownloadProgress {
    let pct_re = Regex::new(r"\[download\]\s+(\d+(?:\.\d+)?)%").unwrap();
    let speed_re = Regex::new(r"\bat\s+(\S+/s)").unwrap();
    let eta_re = Regex::new(r"\bETA\s+(\S+)").unwrap();
    let item_re = Regex::new(r"Downloading\s+(?:item|video)\s+(\d+)\s+of\s+(\d+)").unwrap();
    DownloadProgress {
        line: line.to_string(),
        percent: pct_re.captures(line).and_then(|c|c.get(1)).and_then(|m|m.as_str().parse().ok()),
        speed: speed_re.captures(line).and_then(|c|c.get(1)).map(|m|m.as_str().to_string()),
        eta: eta_re.captures(line).and_then(|c|c.get(1)).map(|m|m.as_str().to_string()),
        item: item_re.captures(line).map(|c|format!("{}/{}", &c[1], &c[2])),
    }
}

#[tauri::command]
fn start_download(app: AppHandle, state: State<AppState>, req: DownloadRequest) -> Result<String,String> {
    if state.download_pid.lock().unwrap().is_some() {
        return Err("Đang có một tác vụ download chạy.".into());
    }
    let settings = get_settings(app.clone())?;
    if settings.media_root.trim().is_empty() { return Err("Chưa cấu hình Media Root.".into()); }
    let media_root = PathBuf::from(settings.media_root);
    let project = ensure_project(&media_root,&req.content_type,&req.project_name)?;
    let source_dir = project.join("01_SOURCE");
    let y = find_tool(&app,&["yt-dlp.exe","yt-dlp"]).ok_or("Không tìm thấy yt-dlp")?;
    let ffmpeg = find_tool(&app,&["ffmpeg.exe","ffmpeg"]);

    let archive = app_data_dir(&app)?.join("downloaded.txt");
    let mut args: Vec<String> = vec![
        "--newline".into(), "--progress".into(), "--no-quiet".into(), "--no-simulate".into(),
        "--continue".into(), "--retries".into(),"10".into(),"--fragment-retries".into(),"10".into(),
        "--concurrent-fragments".into(),"8".into(),"--windows-filenames".into(),
        "--merge-output-format".into(),"mp4".into(),
        "--download-archive".into(), archive.to_string_lossy().to_string(),
    ];
    if let Some(f) = ffmpeg {
        if let Some(parent)=f.parent() {
            args.push("--ffmpeg-location".into()); args.push(parent.to_string_lossy().to_string());
        }
    }
    match req.quality.as_str() {
        "1080" => { args.extend(["-f".into(),"bv[height<=1080]+ba/b[height<=1080]/b".into()]); }
        "best" => { args.extend(["-f".into(),"bv+ba/b".into()]); }
        _ => { args.extend(["-f".into(),"bv[height<=720]+ba/b[height<=720]/b".into()]); }
    }
    match req.playlist_mode.as_str() {
        "single" => args.push("--no-playlist".into()),
        "playlist" => args.push("--yes-playlist".into()),
        _ => {}
    }
    args.push("-o".into());
    args.push(source_dir.join("%(playlist_index)03d - %(title)s [%(id)s].%(ext)s").to_string_lossy().to_string());
    args.push(req.url.clone());

    let mut cmd = Command::new(y);
    cmd.args(args).stdout(Stdio::piped()).stderr(Stdio::piped());
    #[cfg(target_os = "windows")]
    cmd.creation_flags(CREATE_NO_WINDOW);
    let mut child = cmd.spawn().map_err(|e| e.to_string())?;
    let pid = child.id();
    *state.download_pid.lock().unwrap() = Some(pid);

    let stdout = child.stdout.take();
    let stderr = child.stderr.take();
    let pid_store = state.download_pid.clone();
    let app2 = app.clone();

    if let Some(out) = stdout {
        let app3 = app.clone();
        std::thread::spawn(move || {
            for line in BufReader::new(out).lines().flatten() {
                let _ = app3.emit("download-progress", parse_progress(&line));
            }
        });
    }
    if let Some(err) = stderr {
        let app3 = app.clone();
        std::thread::spawn(move || {
            for line in BufReader::new(err).lines().flatten() {
                let _ = app3.emit("download-progress", parse_progress(&line));
            }
        });
    }
    std::thread::spawn(move || {
        let result = child.wait();
        *pid_store.lock().unwrap() = None;
        match result {
            Ok(status) => {
                let ok=status.success();
                let msg=if ok {"Download hoàn tất.".to_string()} else {format!("Download kết thúc với mã {:?}",status.code())};
                let _=app2.emit("download-complete", serde_json::json!({"ok":ok,"message":msg}));
            }
            Err(e) => { let _=app2.emit("download-complete", serde_json::json!({"ok":false,"message":e.to_string()})); }
        }
    });

    Ok(format!("pid:{}",pid))
}

#[tauri::command]
fn stop_download(state: State<AppState>) -> Result<(),String> {
    let pid = *state.download_pid.lock().unwrap();
    let Some(pid)=pid else { return Ok(()); };
    #[cfg(target_os="windows")]
    {
        let mut cmd=Command::new("taskkill");
        cmd.args(["/PID",&pid.to_string(),"/T","/F"]);
        cmd.creation_flags(CREATE_NO_WINDOW);
        let _=cmd.output();
    }
    Ok(())
}

#[tauri::command]
fn list_projects(media_root: String) -> Result<Vec<ProjectItem>,String> {
    let base=PathBuf::from(media_root);
    let mut out=Vec::new();
    for (bucket,kind) in [("PHIM_AI","AI"),("PHIM_THAT","LIVE_ACTION")] {
        let p=base.join(bucket);
        if !p.exists(){continue}
        for entry in fs::read_dir(p).map_err(|e|e.to_string())?.flatten() {
            if entry.file_type().map(|x|x.is_dir()).unwrap_or(false) {
                out.push(ProjectItem {
                    content_type:kind.into(),
                    name:entry.file_name().to_string_lossy().to_string(),
                    path:entry.path().to_string_lossy().to_string()
                });
            }
        }
    }
    out.sort_by(|a,b|a.name.to_lowercase().cmp(&b.name.to_lowercase()));
    Ok(out)
}


#[tauri::command]
async fn check_update(url: String) -> Result<UpdateManifest, String> {
    let ts = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_millis();
    let sep = if url.contains('?') { "&" } else { "?" };
    let fresh_url = format!("{}{}ts={}", url, sep, ts);

    reqwest::Client::new()
        .get(fresh_url)
        .header("User-Agent", "TAI-VIDEO-STUDIO/1.4")
        .header("Cache-Control", "no-cache, no-store, max-age=0")
        .send().await.map_err(|e| e.to_string())?
        .error_for_status().map_err(|e| e.to_string())?
        .json::<UpdateManifest>().await.map_err(|e| e.to_string())
}

fn ps_quote(s: &str) -> String {
    s.replace('\'', "''")
}

#[tauri::command]
fn apply_update(app: AppHandle, manifest: UpdateManifest) -> Result<(), String> {
    if manifest.zip_url.trim().is_empty() {
        return Err("Manifest chưa có zip_url".into());
    }

    let project_root = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .ok_or("Không xác định được project root")?
        .to_path_buf();

    let temp = std::env::temp_dir().join("TAI_VIDEO_STUDIO_UPDATER");
    fs::create_dir_all(&temp).map_err(|e| e.to_string())?;
    let script = temp.join("apply_update.ps1");

    let ps = format!(r#"
$ErrorActionPreference = "Stop"
$Project = '{project}'
$Zip = Join-Path $env:TEMP 'TAI_VIDEO_STUDIO_UPDATE.zip'
$Stage = Join-Path $env:TEMP 'TAI_VIDEO_STUDIO_UPDATE_STAGE'
$Log = Join-Path $env:TEMP 'TAI_VIDEO_STUDIO_UPDATE.log'

Start-Sleep -Seconds 3
"[$(Get-Date)] START update {version}" | Out-File $Log -Encoding utf8

Invoke-WebRequest -UseBasicParsing -Uri '{zip_url}' -OutFile $Zip

$Expected = '{sha}'
if ($Expected -and $Expected.Trim().Length -gt 0) {{
  $Actual = (Get-FileHash -Algorithm SHA256 $Zip).Hash.ToLower()
  if ($Actual -ne $Expected.ToLower()) {{
    throw "SHA256 mismatch"
  }}
}}

if (Test-Path $Stage) {{ Remove-Item $Stage -Recurse -Force }}
New-Item -ItemType Directory -Force $Stage | Out-Null
Expand-Archive -Path $Zip -DestinationPath $Stage -Force

robocopy $Stage $Project /E /XD node_modules target .git BACKUP_V* /XF *.log | Out-File -Append $Log
$rc = $LASTEXITCODE
if ($rc -ge 8) {{ throw "Robocopy failed: $rc" }}

Remove-Item $Stage -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item $Zip -Force -ErrorAction SilentlyContinue

Set-Location $Project
npm.cmd install | Out-File -Append $Log

Start-Process powershell.exe -ArgumentList '-NoExit','-Command',"Set-Location '$Project'; npm.cmd run tauri dev"
"#,
        project = ps_quote(&project_root.to_string_lossy()),
        version = ps_quote(&manifest.version),
        zip_url = ps_quote(&manifest.zip_url),
        sha = ps_quote(&manifest.sha256),
    );

    fs::write(&script, ps).map_err(|e| e.to_string())?;

    let mut cmd = Command::new("powershell.exe");
    cmd.args([
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File",
        &script.to_string_lossy(),
    ]);
    #[cfg(target_os = "windows")]
    cmd.creation_flags(CREATE_NO_WINDOW);
    cmd.spawn().map_err(|e| e.to_string())?;

    app.exit(0);
    Ok(())
}

#[tauri::command]
fn open_path(path: String) -> Result<(),String> {
    #[cfg(target_os="windows")]
    {
        let mut c=Command::new("explorer.exe"); c.arg(path);
        c.creation_flags(CREATE_NO_WINDOW);
        c.spawn().map_err(|e|e.to_string())?;
    }
    Ok(())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .manage(AppState { download_pid: Arc::new(Mutex::new(None)) })
        .invoke_handler(tauri::generate_handler![
            check_tools, check_elevenlabs_env, get_settings, save_settings,
            fetch_source_feed, probe_url, probe_source_stats, start_download, stop_download,
            list_projects, check_update, apply_update, open_path
        ])
        .run(tauri::generate_context!())
        .expect("error while running TAI VIDEO STUDIO");
}
